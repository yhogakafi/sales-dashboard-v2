'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { formatRupiah } from '@/lib/parseBarangTerlaris'
import { exportBarangTerlaris } from '@/lib/exportExcel'

// ─── Constants ────────────────────────────────────────────────────────────────

const DEFAULT_BRAND_CATEGORY = {
  SCELTA: 'Online Underwear',
  GRAPE: 'Online Underwear',
  'GROSIR DALAMANKU': 'Online Underwear',
  TAFT: 'Online Underwear',
  RASENDRIYA: 'Online Underwear',
  'SHINE PAJAMAS': 'Online Sport',
  'ACTIVE WEAR': 'Online Sport',
  'INSPORT IDN': 'Online Sport',
  'SHINE SPORT': 'Online Sport',
  'INGAT FASHION': 'Online Sport',
  'THE PEACH & CO': 'Online Sport',
}

function getBrandFromAccount(pelanggan) {
  if (!pelanggan) return null
  const parts = pelanggan.split(' / ')
  return parts.length > 1 ? parts.slice(1).join(' / ').trim() : pelanggan.trim()
}

function getCategoryForAccount(pelanggan) {
  const brand = getBrandFromAccount(pelanggan)
  return brand ? (DEFAULT_BRAND_CATEGORY[brand] || null) : null
}

// ─── Data fetching ────────────────────────────────────────────────────────────

async function fetchBTData(id) {
  const url = id ? `/api/barang-terlaris-data?id=${encodeURIComponent(id)}` : '/api/barang-terlaris-data'
  const res = await fetch(url, { cache: 'no-store' })
  const body = await res.json()
  if (!res.ok) throw new Error(body.error || 'Gagal memuat data.')
  return body
}

async function fetchStockData() {
  const res = await fetch('/api/stock', { cache: 'no-store' })
  if (!res.ok) return {}
  const body = await res.json()
  return body.stockMap || {}
}

// ─── Filter & aggregate helpers ───────────────────────────────────────────────

function aggregateRows(rawRows, { account, category, dateFrom, dateTo }, sortBy = 'kuantitas') {
  const byBarang = {}

  for (const r of rawRows) {
    if (dateFrom && r.dateKey < dateFrom) continue
    if (dateTo   && r.dateKey > dateTo)   continue
    if (account && r.pelanggan !== account) continue
    if (category) {
      const cat = getCategoryForAccount(r.pelanggan)
      if (cat !== category) continue
    }
    if (!byBarang[r.namaBarang]) byBarang[r.namaBarang] = { kuantitas: 0, hargaProduk: 0 }
    byBarang[r.namaBarang].kuantitas   += r.kuantitas
    byBarang[r.namaBarang].hargaProduk += r.hargaProduk
  }

  const sortFn = sortBy === 'hargaProduk'
    ? (a, b) => b[1].hargaProduk - a[1].hargaProduk
    : sortBy === 'namaBarang'
    ? (a, b) => a[0].localeCompare(b[0], 'id')
    : sortBy === 'brand'
    ? (a, b) => (a[2] || '').localeCompare(b[2] || '', 'id')
    : (a, b) => b[1].kuantitas - a[1].kuantitas

  return Object.entries(byBarang)
    .sort(sortFn)
    .map(([namaBarang, v], i) => ({
      rank: i + 1,
      namaBarang,
      kuantitas: v.kuantitas,
      hargaProduk: v.hargaProduk,
    }))
}

// ─── Column filter definitions ────────────────────────────────────────────────

const TEXT_OPS = [
  { value: 'contains',        label: 'Mengandung' },
  { value: 'not_contains',    label: 'Tidak mengandung' },
  { value: 'equals',          label: 'Sama dengan' },
  { value: 'not_equals',      label: 'Tidak sama dengan' },
  { value: 'starts_with',     label: 'Dimulai dengan' },
  { value: 'ends_with',       label: 'Diakhiri dengan' },
  { value: 'is_empty',        label: 'Kosong' },
  { value: 'is_not_empty',    label: 'Tidak kosong' },
]

const NUM_OPS = [
  { value: 'eq',      label: '= Sama dengan' },
  { value: 'neq',     label: '≠ Tidak sama dengan' },
  { value: 'gt',      label: '> Lebih dari' },
  { value: 'gte',     label: '≥ Lebih dari atau sama dengan' },
  { value: 'lt',      label: '< Kurang dari' },
  { value: 'lte',     label: '≤ Kurang dari atau sama dengan' },
  { value: 'between', label: '↔ Di antara' },
]

const EMPTY_COL_FILTER = { op: '', value: '', value2: '' }

function applyColFilter(rows, colFilters) {
  return rows.filter(row => {
    for (const [col, f] of Object.entries(colFilters)) {
      if (!f.op) continue
      const noVal = ['is_empty', 'is_not_empty'].includes(f.op)
      if (!noVal && f.value === '' && f.op !== 'between') continue
      if (f.op === 'between' && f.value === '' && f.value2 === '') continue

      if (col === 'namaBarang' || col === 'brand') {
        const cell = (col === 'brand' ? (row.brand || '') : row.namaBarang).toLowerCase()
        const val  = f.value.toLowerCase()
        if (f.op === 'contains'     && !cell.includes(val))    return false
        if (f.op === 'not_contains' && cell.includes(val))     return false
        if (f.op === 'equals'       && cell !== val)           return false
        if (f.op === 'not_equals'   && cell === val)           return false
        if (f.op === 'starts_with'  && !cell.startsWith(val))  return false
        if (f.op === 'ends_with'    && !cell.endsWith(val))    return false
        if (f.op === 'is_empty'     && cell.trim() !== '')     return false
        if (f.op === 'is_not_empty' && cell.trim() === '')     return false
      } else {
        const cell = col === 'kuantitas' ? row.kuantitas
                   : col === 'stock'    ? (row.stock ?? 0)
                   : row.hargaProduk
        const val  = parseFloat(f.value)
        const val2 = parseFloat(f.value2)
        if (f.op === 'eq'      && cell !== val)              return false
        if (f.op === 'neq'     && cell === val)              return false
        if (f.op === 'gt'      && !(cell > val))             return false
        if (f.op === 'gte'     && !(cell >= val))            return false
        if (f.op === 'lt'      && !(cell < val))             return false
        if (f.op === 'lte'     && !(cell <= val))            return false
        if (f.op === 'between' && !(cell >= val && cell <= val2)) return false
      }
    }
    return true
  })
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function FilterBar({ accounts, filters, onChange }) {
  const categories = ['Online Underwear', 'Online Sport']

  return (
    <div className="bt-filter-bar">
      <div className="period-picker-group">
        <label className="period-picker-label">Akun</label>
        <select
          className="category-select"
          value={filters.account}
          onChange={e => onChange({ ...filters, account: e.target.value, category: '' })}
        >
          <option value="">Semua akun</option>
          {accounts.map(a => (
            <option key={a} value={a}>{a}</option>
          ))}
        </select>
      </div>

      {!filters.account && (
        <div className="period-picker-group">
          <label className="period-picker-label">Kategori</label>
          <div className="pill-group">
            <button
              className={`pill-btn ${!filters.category ? 'is-active' : ''}`}
              style={!filters.category ? { background: 'var(--ink)', color: '#fff' } : {}}
              onClick={() => onChange({ ...filters, category: '' })}
            >
              Semua
            </button>
            {categories.map(cat => (
              <button
                key={cat}
                className={`pill-btn ${filters.category === cat ? 'is-active' : ''} ${
                  cat.includes('Underwear') ? 'pill-underwear' : 'pill-sport'
                }`}
                onClick={() => onChange({ ...filters, category: filters.category === cat ? '' : cat })}
              >
                {cat.replace('Online ', '')}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="period-picker-group">
        <label className="period-picker-label">Tanggal mulai</label>
        <input
          type="date"
          className="login-input bt-date-input"
          value={filters.dateFrom}
          onChange={e => onChange({ ...filters, dateFrom: e.target.value })}
        />
      </div>
      <div className="period-picker-group">
        <label className="period-picker-label">Tanggal akhir</label>
        <input
          type="date"
          className="login-input bt-date-input"
          value={filters.dateTo}
          onChange={e => onChange({ ...filters, dateTo: e.target.value })}
        />
      </div>

      {(filters.account || filters.category || filters.dateFrom || filters.dateTo) && (
        <div className="period-picker-group" style={{ justifyContent: 'flex-end' }}>
          <button
            className="pill-btn"
            onClick={() => onChange({ account: '', category: '', dateFrom: '', dateTo: '' })}
          >
            ✕ Reset filter
          </button>
        </div>
      )}
    </div>
  )
}

function SortIcon({ active, asc = false }) {
  return (
    <span style={{ marginLeft: 4, opacity: active ? 1 : 0.25, fontSize: 11 }}>
      {active && asc ? '↑' : '↓'}
    </span>
  )
}

function HighlightText({ text, query }) {
  if (!query.trim()) return <>{text}</>
  const keyword = query.trim().toLowerCase()
  const idx = text.toLowerCase().indexOf(keyword)
  if (idx === -1) return <>{text}</>
  return (
    <>
      {text.slice(0, idx)}
      <mark style={{ background: '#fde68a', color: 'inherit', borderRadius: 2, padding: '0 2px' }}>
        {text.slice(idx, idx + keyword.length)}
      </mark>
      {text.slice(idx + keyword.length)}
    </>
  )
}

// ── Column filter popover ─────────────────────────────────────────────────────

function ColFilterPopover({ col, filter, onChange, onClose, anchorRef }) {
  const isText  = col === 'namaBarang' || col === 'brand'
  const ops     = isText ? TEXT_OPS : NUM_OPS
  const ref     = useRef(null)

  useEffect(() => {
    function handle(e) {
      if (ref.current && !ref.current.contains(e.target) &&
          anchorRef.current && !anchorRef.current.contains(e.target)) {
        onClose()
      }
    }
    document.addEventListener('mousedown', handle)
    return () => document.removeEventListener('mousedown', handle)
  }, [onClose, anchorRef])

  const noValueOps  = ['is_empty', 'is_not_empty']
  const isBetween   = filter.op === 'between'
  const hideInput   = noValueOps.includes(filter.op)

  const inputStyle = {
    width: '100%', padding: '6px 10px', borderRadius: 6,
    border: '1px solid var(--border, #ddd)',
    background: 'var(--surface, #fff)',
    color: 'var(--ink, #111)',
    fontSize: 13, marginTop: 6, boxSizing: 'border-box',
  }

  return (
    <div ref={ref} style={{
      position: 'absolute',
      top: '100%',
      left: 0,
      zIndex: 200,
      background: 'var(--surface, #fff)',
      border: '1px solid var(--border, #ddd)',
      borderRadius: 10,
      boxShadow: '0 8px 24px rgba(0,0,0,.12)',
      padding: '0.85rem',
      minWidth: 240,
      marginTop: 4,
    }}>
      <select
        value={filter.op}
        onChange={e => onChange({ ...filter, op: e.target.value, value: '', value2: '' })}
        style={{ ...inputStyle, marginTop: 0 }}
      >
        <option value="">— Pilih kondisi —</option>
        {ops.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>

      {filter.op && !hideInput && (
        <>
          <input
            type={isText ? 'text' : 'number'}
            placeholder={isBetween ? 'Nilai minimum' : 'Nilai'}
            value={filter.value}
            onChange={e => onChange({ ...filter, value: e.target.value })}
            style={inputStyle}
            autoFocus
          />
          {isBetween && (
            <input
              type="number"
              placeholder="Nilai maksimum"
              value={filter.value2}
              onChange={e => onChange({ ...filter, value2: e.target.value })}
              style={inputStyle}
            />
          )}
        </>
      )}

      <div style={{ display: 'flex', gap: 6, marginTop: 10, justifyContent: 'flex-end' }}>
        <button
          onClick={() => { onChange(EMPTY_COL_FILTER); onClose() }}
          style={{
            padding: '5px 12px', borderRadius: 6, border: '1px solid var(--border, #ddd)',
            background: 'none', cursor: 'pointer', fontSize: 12,
            color: 'var(--muted, #888)',
          }}
        >
          Hapus
        </button>
        <button
          onClick={onClose}
          style={{
            padding: '5px 12px', borderRadius: 6, border: 'none',
            background: 'var(--ink, #111)', color: '#fff',
            cursor: 'pointer', fontSize: 12, fontWeight: 600,
          }}
        >
          Terapkan
        </button>
      </div>
    </div>
  )
}

// ── Column header with sort + filter ─────────────────────────────────────────

function ColHeader({ col, label, align = 'left', sortBy, onSortChange, colFilters, onColFilterChange }) {
  const [open, setOpen] = useState(false)
  const btnRef = useRef(null)
  const filter  = colFilters[col] || EMPTY_COL_FILTER
  const isActive = !!(filter.op && (
    ['is_empty', 'is_not_empty'].includes(filter.op) || filter.value !== ''
  ))

  return (
    <th
      style={{
        textAlign: align,
        whiteSpace: 'nowrap',
        position: 'relative',
        userSelect: 'none',
      }}
    >
      <span
        onClick={() => onSortChange(col)}
        style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 2 }}
        title={`Urutkan berdasarkan ${label}`}
      >
        {align === 'right' && <SortIcon active={sortBy === col} />}
        {label}
        {align === 'left'  && <SortIcon active={sortBy === col} asc={true} />}
      </span>

      <button
        ref={btnRef}
        onClick={e => { e.stopPropagation(); setOpen(v => !v) }}
        title="Filter kolom"
        style={{
          marginLeft: 5,
          padding: '1px 5px',
          borderRadius: 4,
          border: `1px solid ${isActive ? 'var(--accent-2, #6366f1)' : 'var(--border, #ddd)'}`,
          background: isActive ? 'var(--accent-2, #6366f1)' : 'transparent',
          color: isActive ? '#fff' : 'var(--muted, #888)',
          cursor: 'pointer',
          fontSize: 11,
          lineHeight: 1.4,
          verticalAlign: 'middle',
        }}
      >
        {isActive ? '▼●' : '▼'}
      </button>

      {open && (
        <ColFilterPopover
          col={col}
          filter={filter}
          onChange={f => onColFilterChange(col, f)}
          onClose={() => setOpen(false)}
          anchorRef={btnRef}
        />
      )}
    </th>
  )
}

// ── Stock badge ───────────────────────────────────────────────────────────────

function StockBadge({ stock, stockLoaded }) {
  if (!stockLoaded) {
    return <span className="muted" style={{ fontSize: 12 }}>—</span>
  }
  if (stock == null) {
    return <span className="muted" style={{ fontSize: 12 }}>0</span>
  }
  const isLow  = stock > 0 && stock <= 10
  const isZero = stock === 0
  return (
    <span
      className="mono"
      style={{
        fontWeight: 600,
        color: isZero ? 'var(--danger, #ef4444)'
             : isLow  ? 'var(--warning, #f59e0b)'
             : 'inherit',
      }}
    >
      {stock.toLocaleString('id-ID')}
    </span>
  )
}

// ── Main table component ──────────────────────────────────────────────────────

function BestSellerTable({
  rows, loading, sortBy, onSortChange,
  searchQuery, onSearchChange,
  colFilters, onColFilterChange,
  stockLoaded,
}) {
  const totalKuantitas   = rows.reduce((s, r) => s + r.kuantitas, 0)
  const totalHargaProduk = rows.reduce((s, r) => s + r.hargaProduk, 0)

  const colHeaderProps = { sortBy, onSortChange, colFilters, onColFilterChange }

  return (
    <>
      {/* ── Search bar ── */}
      <div style={{ marginBottom: '0.75rem', position: 'relative' }}>
        <span style={{
          position: 'absolute', left: '0.75rem', top: '50%',
          transform: 'translateY(-50%)', fontSize: 15,
          color: 'var(--muted, #888)', pointerEvents: 'none',
        }}>🔍</span>
        <input
          type="text"
          className="login-input"
          placeholder="Cari nama barang…"
          value={searchQuery}
          onChange={e => onSearchChange(e.target.value)}
          style={{ paddingLeft: '2.25rem', paddingRight: searchQuery ? '2.25rem' : undefined }}
        />
        {searchQuery && (
          <button
            onClick={() => onSearchChange('')}
            style={{
              position: 'absolute', right: '0.6rem', top: '50%',
              transform: 'translateY(-50%)', background: 'none', border: 'none',
              cursor: 'pointer', fontSize: 16, color: 'var(--muted, #888)',
              lineHeight: 1, padding: '0 4px',
            }}
            title="Hapus pencarian"
          >✕</button>
        )}
      </div>

      {loading && <p className="loading-text">Memuat data…</p>}

      {!loading && !rows.length && (
        <div className="upload-zone has-error" style={{ textAlign: 'center', padding: '2.5rem' }}>
          <p className="upload-title">Tidak ada produk ditemukan</p>
          <p className="upload-sub">
            {searchQuery
              ? `Tidak ada produk yang cocok dengan "${searchQuery}". Coba kata kunci lain.`
              : 'Coba ubah filter kolom, tanggal, akun, atau kategori.'}
          </p>
        </div>
      )}

      {!loading && rows.length > 0 && (
        <>
          {/* ── Grand total summary ── */}
          <div style={{ display: 'flex', gap: '1rem', marginBottom: '0.75rem', flexWrap: 'wrap' }}>
            <div style={{
              flex: 1, minWidth: 140,
              background: 'var(--surface-2, #f5f5f5)', borderRadius: 8, padding: '0.6rem 1rem',
            }}>
              <p className="muted" style={{ fontSize: 12, margin: 0 }}>Total Kuantitas</p>
              <p className="mono" style={{ fontSize: 18, fontWeight: 700, margin: '2px 0 0' }}>
                {totalKuantitas.toLocaleString('id-ID')}
              </p>
            </div>
            <div style={{
              flex: 1, minWidth: 140,
              background: 'var(--surface-2, #f5f5f5)', borderRadius: 8, padding: '0.6rem 1rem',
            }}>
              <p className="muted" style={{ fontSize: 12, margin: 0 }}>Total Harga Produk</p>
              <p className="mono" style={{ fontSize: 18, fontWeight: 700, margin: '2px 0 0' }}>
                {formatRupiah(totalHargaProduk)}
              </p>
            </div>
          </div>

          {/* ── Search result count ── */}
          {searchQuery.trim() && (
            <p className="period-note" style={{ marginBottom: '0.5rem', marginTop: 0 }}>
              Menampilkan {rows.length} produk untuk pencarian &ldquo;{searchQuery}&rdquo;
            </p>
          )}

          {/* ── Table ── */}
          <div className="table-scroll" style={{ overflowX: 'auto' }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th style={{ width: 44 }}>#</th>
                  <ColHeader col="namaBarang"   label="Nama Barang"   align="left"  {...colHeaderProps} />
                  <ColHeader col="brand"        label="Brand"         align="left"  {...colHeaderProps} />
                  <ColHeader col="stock"        label="Stock"         align="right" {...colHeaderProps} />
                  <ColHeader col="kuantitas"    label="Kuantitas"     align="right" {...colHeaderProps} />
                  <ColHeader col="hargaProduk"  label="Harga Produk"  align="right" {...colHeaderProps} />
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.namaBarang}>
                    <td className="muted mono" style={{ textAlign: 'center' }}>{row.rank}</td>
                    <td style={{ fontWeight: 500 }}>
                      <HighlightText text={row.namaBarang} query={searchQuery} />
                    </td>
                    <td style={{ fontSize: 13 }}>
                      {stockLoaded
                        ? (row.brand || <span className="muted">—</span>)
                        : <span className="muted">—</span>
                      }
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <StockBadge stock={row.stock} stockLoaded={stockLoaded} />
                    </td>
                    <td className="mono" style={{ textAlign: 'right' }}>
                      {row.kuantitas.toLocaleString('id-ID')}
                    </td>
                    <td className="mono" style={{ textAlign: 'right' }}>
                      {formatRupiah(row.hargaProduk)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </>
  )
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function ProdukTerlarisPage() {
  const [loggedIn, setLoggedIn]               = useState(false)
  const [checkingSession, setCheckingSession] = useState(true)
  const [password, setPassword]               = useState('')
  const [loginError, setLoginError]           = useState(null)
  const [loginLoading, setLoginLoading]       = useState(false)

  // Periods
  const [periods, setPeriods]       = useState([])
  const [selectedId, setSelectedId] = useState('')

  // BT Data
  const [payload, setPayload]         = useState(null)
  const [dataLoading, setDataLoading] = useState(false)
  const [dataError, setDataError]     = useState(null)

  // Stock data
  const [stockMap, setStockMap]       = useState({})
  const [stockLoaded, setStockLoaded] = useState(false)

  // Date / account / category filters
  const [filters, setFilters] = useState({
    account:  '',
    category: '',
    dateFrom: '',
    dateTo:   '',
  })

  // Sort
  const [sortBy, setSortBy] = useState('kuantitas')

  // Search
  const [searchQuery, setSearchQuery] = useState('')

  // Column filters
  const [colFilters, setColFilters] = useState({})

  const handleColFilterChange = useCallback((col, f) => {
    setColFilters(prev => ({ ...prev, [col]: f }))
  }, [])

  // ── Session check ────────────────────────────────────────────────────────────
  useEffect(() => {
    fetch('/api/session', { cache: 'no-store' })
      .then(async (res) => {
        setCheckingSession(false)
        if (!res.ok) return
        setLoggedIn(true)
        loadPeriods()
        loadData('')
        loadStock()
      })
      .catch(() => setCheckingSession(false))
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // ── Load stock ───────────────────────────────────────────────────────────────
  const loadStock = useCallback(async () => {
    try {
      const map = await fetchStockData()
      setStockMap(map)
      setStockLoaded(true)
    } catch {
      setStockLoaded(true) // treat as loaded even if failed — shows 0
    }
  }, [])

  // ── Load periods ─────────────────────────────────────────────────────────────
  const loadPeriods = useCallback(async () => {
    const res = await fetch('/api/barang-terlaris-periods', { cache: 'no-store' })
    if (res.ok) setPeriods(await res.json())
  }, [])

  // ── Load data ─────────────────────────────────────────────────────────────────
  const loadData = useCallback(async (id) => {
    setDataLoading(true)
    setDataError(null)
    try {
      const d = await fetchBTData(id)
      setPayload(d)
    } catch (err) {
      setDataError(err.message)
      setPayload(null)
    } finally {
      setDataLoading(false)
    }
  }, [])

  const handlePeriodChange = useCallback((newId) => {
    setSelectedId(newId)
    loadData(newId)
  }, [loadData])

  // ── Login ─────────────────────────────────────────────────────────────────────
  const handleLogin = useCallback(async (e) => {
    e.preventDefault()
    setLoginError(null)
    setLoginLoading(true)
    try {
      const res = await fetch('/api/viewer-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      })
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'Password salah.')
      setLoggedIn(true)
      await loadPeriods()
      await loadData('')
      loadStock()
    } catch (err) {
      setLoginError(err.message)
    } finally {
      setLoginLoading(false)
    }
  }, [password, loadPeriods, loadData, loadStock])

  // ── Derived data ──────────────────────────────────────────────────────────────
  const analysis = payload?.analysis
  const rawRows  = analysis?.rawRows  || []
  const accounts = analysis?.accounts || []

  useEffect(() => {
    if (!analysis) return
    setFilters(f => ({
      ...f,
      dateFrom: f.dateFrom || analysis.firstDateKey || '',
      dateTo:   f.dateTo   || analysis.lastDateKey  || '',
    }))
  }, [analysis?.firstDateKey, analysis?.lastDateKey]) // eslint-disable-line react-hooks/exhaustive-deps

  const filteredRows = useMemo(() => {
    // 1. aggregate + date/account/category filter + sort
    let rows = aggregateRows(rawRows, filters, sortBy)

    // 2. inject brand & stock from stockMap
    rows = rows.map(r => {
      const entry = stockMap[r.namaBarang]
      return {
        ...r,
        brand: entry?.brand ?? null,
        stock: entry?.stock ?? null,
      }
    })

    // 3. global search (substring, case-insensitive)
    if (searchQuery.trim()) {
      const kw = searchQuery.trim().toLowerCase()
      rows = rows.filter(r => r.namaBarang.toLowerCase().includes(kw))
    }

    // 4. column filters
    rows = applyColFilter(rows, colFilters)

    // 5. re-rank after all filters
    return rows.map((r, i) => ({ ...r, rank: i + 1 }))
  }, [rawRows, filters, sortBy, searchQuery, colFilters, stockMap])

  // ── Active filter description ──────────────────────────────────────────────────
  const activeFilterDesc = useMemo(() => {
    const parts = []
    if (filters.account)  parts.push(`Akun: ${filters.account}`)
    if (filters.category) parts.push(`Kategori: ${filters.category}`)
    if (filters.dateFrom || filters.dateTo) {
      const from = filters.dateFrom || analysis?.firstDateKey || '…'
      const to   = filters.dateTo   || analysis?.lastDateKey  || '…'
      parts.push(`Tanggal: ${from} s.d. ${to}`)
    }
    const colLabels = {
      namaBarang: 'Nama Barang', brand: 'Brand',
      stock: 'Stock', kuantitas: 'Kuantitas', hargaProduk: 'Harga Produk',
    }
    for (const [col, f] of Object.entries(colFilters)) {
      if (!f.op) continue
      const noVal = ['is_empty', 'is_not_empty'].includes(f.op)
      if (!noVal && f.value === '' && f.op !== 'between') continue
      const opLabel = [...TEXT_OPS, ...NUM_OPS].find(o => o.value === f.op)?.label || f.op
      const valPart = noVal ? '' : f.op === 'between' ? ` ${f.value}–${f.value2}` : ` "${f.value}"`
      parts.push(`${colLabels[col]}: ${opLabel}${valPart}`)
    }
    return parts.length ? parts.join(' · ') : null
  }, [filters, analysis, colFilters])

  const activeColFilterCount = useMemo(() => {
    return Object.values(colFilters).filter(f => {
      if (!f.op) return false
      if (['is_empty', 'is_not_empty'].includes(f.op)) return true
      return f.value !== ''
    }).length
  }, [colFilters])

  const resetColFilters = () => setColFilters({})

  // ── Render ────────────────────────────────────────────────────────────────────

  if (checkingSession) {
    return <div className="app-shell admin-login-shell"><p className="loading-text">Memeriksa sesi…</p></div>
  }

  if (!loggedIn) {
    return (
      <div className="app-shell admin-login-shell">
        <form className="login-card" onSubmit={handleLogin}>
          <p className="eyebrow">Produk Terlaris</p>
          <h1>Masukkan password tim untuk melihat</h1>
          <input
            type="password"
            placeholder="Password tim"
            value={password}
            onChange={e => setPassword(e.target.value)}
            className="login-input"
            autoFocus
          />
          {loginError && <p className="upload-error">{loginError}</p>}
          <button type="submit" className="btn-export" disabled={loginLoading}>
            {loginLoading ? 'Memeriksa…' : 'Masuk'}
          </button>
        </form>
      </div>
    )
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <div>
          <p className="eyebrow">Dashboard penjualan</p>
          <h1>Produk Terlaris</h1>
        </div>
      </header>

      {/* ── Period picker ── */}
      {periods.length > 0 && (
        <div className="period-picker">
          <div className="period-picker-group">
            <label className="period-picker-label">Periode data</label>
            <select
              className="category-select"
              value={selectedId}
              onChange={e => handlePeriodChange(e.target.value)}
            >
              <option value="">Terbaru ({periods[0]?.label})</option>
              {periods.map(p => (
                <option key={p.id} value={p.id}>
                  {p.label} — {p.dateRange}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}

      {/* ── No data yet ── */}
      {!dataLoading && dataError && (
        <div className="upload-zone has-error">
          <p className="upload-title">Belum ada data untuk ditampilkan</p>
          <p className="upload-sub">{dataError}</p>
        </div>
      )}

      {/* ── Main content ── */}
      {!dataError && (
        <div className="table-block">
          {/* Header row */}
          <div className="table-block-header">
            <h3 className="block-title">Produk paling banyak terjual</h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
              {analysis && (
                <span className="muted" style={{ fontSize: 13 }}>
                  {analysis.periodLabel}
                  {payload?.savedAt && (
                    <> &middot; Diperbarui {new Date(payload.savedAt).toLocaleString('id-ID')}</>
                  )}
                </span>
              )}
              {!stockLoaded && (
                <span className="muted" style={{ fontSize: 12 }}>Memuat stock…</span>
              )}
              {activeColFilterCount > 0 && (
                <button
                  className="pill-btn"
                  onClick={resetColFilters}
                  style={{
                    background: 'var(--accent-2, #6366f1)',
                    color: '#fff',
                    border: 'none',
                    fontSize: 12,
                  }}
                >
                  ✕ Reset filter kolom ({activeColFilterCount})
                </button>
              )}
              {filteredRows.length > 0 && (
                <button
                  className="btn-export"
                  style={{ padding: '7px 14px', fontSize: 13 }}
                  onClick={() => exportBarangTerlaris(filteredRows, {
                    periodLabel: analysis?.periodLabel,
                    filterDesc: activeFilterDesc,
                  })}
                >
                  ↓ Ekspor Excel
                </button>
              )}
            </div>
          </div>

          {/* Filter bar */}
          {analysis && (
            <FilterBar
              accounts={accounts}
              filters={filters}
              onChange={newFilters => setFilters(newFilters)}
            />
          )}

          {/* Active filter note */}
          {activeFilterDesc && (
            <p className="period-note" style={{ marginBottom: '0.75rem', marginTop: 0 }}>
              Filter aktif: {activeFilterDesc}
              {' '}({filteredRows.length} produk)
            </p>
          )}

          {/* Table */}
          <BestSellerTable
            rows={filteredRows}
            loading={dataLoading}
            sortBy={sortBy}
            onSortChange={setSortBy}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            colFilters={colFilters}
            onColFilterChange={handleColFilterChange}
            stockLoaded={stockLoaded}
          />
        </div>
      )}
    </div>
  )
}
