'use client'

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { formatRupiah, formatDateLabel } from '@/lib/parseBarangTerlaris'
import { exportBarangTerlaris } from '@/lib/exportExcel'
import { lookupSkuEntry, buildSkuIndex, parseSkuImageFile } from '@/lib/parseSkuImage'

// ─── Stock lookup helper ───────────────────────────────────────────────────────

// stockLookup[kode] sekarang berbentuk { underwear: entryOrNull, sport: entryOrNull }
// — dipisah per sumber (bukan digabung jadi satu), supaya kode yang kebetulan
// ada di kedua file (mis. underwear.xls yang sebetulnya inventaris lengkap)
// bisa ditangani sesuai konteks: gabung saat "Semua", pisah saat kategori dipilih.
function getStockInfo(kodeBarang, stockLookup, category) {
  if (!stockLookup || !kodeBarang) return { brand: '—', stock: 0, unit: '', nama: null, hpp: 0, hasData: false }
  const entry = stockLookup[kodeBarang]
  if (!entry) return { brand: '—', stock: 0, unit: '', nama: null, hpp: 0, hasData: false }

  const wantedSource = category ? CATEGORY_TO_STOCK_SOURCE[category] : null

  if (wantedSource) {
    const data = entry[wantedSource]
    if (!data) return { brand: '—', stock: 0, unit: '', nama: null, hpp: 0, hasData: false }
    return { brand: data.brand || '—', stock: data.stock ?? 0, unit: data.unit || '', nama: data.nama || null, hpp: data.hpp ?? 0, hasData: true }
  }

  // "Semua" — gabungkan stock dari kedua sumber
  const u = entry.underwear
  const s = entry.sport
  if (u && s) {
    const combinedStock = (u.stock || 0) + (s.stock || 0)
    const combinedValue = (u.hpp || 0) * (u.stock || 0) + (s.hpp || 0) * (s.stock || 0)
    const combinedHpp = combinedStock > 0 ? combinedValue / combinedStock : 0
    return { brand: u.brand || s.brand || '—', stock: combinedStock, unit: u.unit || s.unit || '', nama: u.nama || s.nama || null, hpp: combinedHpp, hasData: true }
  }
  const only = u || s
  return { brand: only.brand || '—', stock: only.stock ?? 0, unit: only.unit || '', nama: only.nama || null, hpp: only.hpp ?? 0, hasData: true }
}

// ─── Constants ────────────────────────────────────────────────────────────────

const DEFAULT_BRAND_CATEGORY = {
  SCELTA: 'Online Underwear',
  GRAPE: 'Online Underwear',
  'GROSIR DALAMANKU': 'Online Underwear',
  TAFT: 'Online Underwear',
  RASENDRIYA: 'Online Underwear',
  'SHINE PAJAMAS': 'Online Sport',
  'ACTIVE WEAR': 'Online Sport',
  'INSPORT IDN': 'Online Sport',
  'SHINE SPORT': 'Online Sport',
  'INGAT FASHION': 'Online Sport',
  'THE PEACH & CO': 'Online Sport',
}

function getBrandFromAccount(pelanggan) {
  if (!pelanggan) return null
  const parts = pelanggan.split(' / ')
  return parts.length > 1 ? parts.slice(1).join(' / ').trim() : pelanggan.trim()
}

function getCategoryForAccount(pelanggan) {
  const brand = getBrandFromAccount(pelanggan)
  return brand ? (DEFAULT_BRAND_CATEGORY[brand] || null) : null
}

// ─── Data fetching ────────────────────────────────────────────────────────────

async function fetchBTData(id) {
  const url = id ? `/api/barang-terlaris-data?id=${encodeURIComponent(id)}` : '/api/barang-terlaris-data'
  const res = await fetch(url, { cache: 'no-store' })
  const body = await res.json()
  if (!res.ok) throw new Error(body.error || 'Gagal memuat data.')
  return body
}

// ─── "1 Bulan Terakhir" (rolling 30-day) helpers ──────────────────────────────
// Periode disimpan per bulan kalender (satu JSON per bulan), jadi window 30 hari
// bisa memotong 2 bulan sekaligus (mis. hari ini 10 Agustus → butuh Juli + Agustus).
// Solusinya: gabungkan rawRows dari 2 periode terbaru, lalu filter ulang by dateKey
// di client — tidak perlu ubah cara data disimpan.

function toDateKey(d) {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

function last30DaysRange() {
  const to = new Date()
  const from = new Date()
  from.setDate(from.getDate() - 29) // 30 hari termasuk hari ini
  return { dateFrom: toDateKey(from), dateTo: toDateKey(to) }
}

const ALL_MERGED_ID = 'all-merged'

// ─── Filter & aggregate helpers ───────────────────────────────────────────────

function passesFilters(r, { account, category, dateFrom, dateTo }) {
  if (dateFrom && r.dateKey < dateFrom) return false
  if (dateTo && r.dateKey > dateTo) return false
  if (account && r.pelanggan !== account) return false
  if (category) {
    const cat = getCategoryForAccount(r.pelanggan)
    if (cat !== category) return false
  }
  return true
}

function aggregateRows(rawRows, filters) {
  const byBarang = {}

  for (const r of rawRows) {
    if (!passesFilters(r, filters)) continue
    if (!byBarang[r.namaBarang]) {
      byBarang[r.namaBarang] = { kuantitas: 0, hargaProduk: 0, kodeBarang: r.kodeBarang || null }
    }
    byBarang[r.namaBarang].kuantitas += r.kuantitas
    byBarang[r.namaBarang].hargaProduk += r.hargaProduk
    if (!byBarang[r.namaBarang].kodeBarang && r.kodeBarang) {
      byBarang[r.namaBarang].kodeBarang = r.kodeBarang
    }
  }

  return Object.entries(byBarang).map(([namaBarang, v]) => ({
    namaBarang,
    kodeBarang: v.kodeBarang,
    kuantitas: v.kuantitas,
    hargaProduk: v.hargaProduk,
  }))
}

// ─── Sales aggregated by kode (needed to match onto the stock master) ─────────

function aggregateSalesByKode(rawRows, filters) {
  const byKode = {}  // { kode: { namaBarang, kuantitas, hargaProduk } } — rows that have a kodeBarang
  const byNamaOnly = {}  // { namaBarang: { kuantitas, hargaProduk } } — rows with no kodeBarang at all

  for (const r of rawRows) {
    if (!passesFilters(r, filters)) continue
    if (r.kodeBarang) {
      if (!byKode[r.kodeBarang]) {
        byKode[r.kodeBarang] = { namaBarang: r.namaBarang, kuantitas: 0, hargaProduk: 0 }
      }
      byKode[r.kodeBarang].kuantitas += r.kuantitas
      byKode[r.kodeBarang].hargaProduk += r.hargaProduk
    } else {
      if (!byNamaOnly[r.namaBarang]) {
        byNamaOnly[r.namaBarang] = { kuantitas: 0, hargaProduk: 0 }
      }
      byNamaOnly[r.namaBarang].kuantitas += r.kuantitas
      byNamaOnly[r.namaBarang].hargaProduk += r.hargaProduk
    }
  }

  return { byKode, byNamaOnly }
}

// ─── Stock-first row builder ───────────────────────────────────────────────
// Starts from every SKU in the stock master (underwear + sport), then matches
// in sales data by kodeBarang. Stock SKUs with no matching sales keep
// kuantitas/hargaProduk at 0 instead of being left out.

// Kategori pill ('Online Underwear' / 'Online Sport') → source di stock master.
const CATEGORY_TO_STOCK_SOURCE = {
  'Online Underwear': 'underwear',
  'Online Sport': 'sport',
}

function buildStockFirstRows(rawRows, filters, stockLookup) {
  const { byKode, byNamaOnly } = aggregateSalesByKode(rawRows, filters)
  const consumedKodes = new Set()
  const rows = []

  // Kalau pill kategori aktif, batasi SKU stock yang ditampilkan ke sumber file
  // yang sesuai (underwear.json / sport.json) — bukan cuma memfilter penjualannya.
  const wantedSource = filters.category ? CATEGORY_TO_STOCK_SOURCE[filters.category] : null

  // 1. Every SKU from the stock master, always shown — even with zero sales.
  for (const [kode, stockEntry] of Object.entries(stockLookup)) {
    if (wantedSource && !stockEntry[wantedSource]) continue
    const sales = byKode[kode]
    consumedKodes.add(kode)
    // stockEntry sekarang { underwear, sport } (dipisah per sumber) — ambil nama
    // dari sumber yang sedang aktif kalau ada pill kategori, atau dari sumber
    // manapun yang punya datanya kalau "Semua".
    const stockNama = wantedSource
      ? stockEntry[wantedSource]?.nama
      : (stockEntry.underwear?.nama || stockEntry.sport?.nama)
    rows.push({
      namaBarang: sales?.namaBarang || stockNama || kode,
      kodeBarang: kode,
      kuantitas: sales?.kuantitas || 0,
      hargaProduk: sales?.hargaProduk || 0,
    })
  }

  // 2. Sold items whose kode isn't in the current stock master (e.g. stock file
  //    is out of date) — keep them visible too, just without brand/stock info.
  for (const [kode, sales] of Object.entries(byKode)) {
    if (consumedKodes.has(kode)) continue
    rows.push({
      namaBarang: sales.namaBarang,
      kodeBarang: kode,
      kuantitas: sales.kuantitas,
      hargaProduk: sales.hargaProduk,
    })
  }

  // 3. Sold items with no kodeBarang at all — can't be matched to stock.
  for (const [namaBarang, sales] of Object.entries(byNamaOnly)) {
    rows.push({
      namaBarang,
      kodeBarang: null,
      kuantitas: sales.kuantitas,
      hargaProduk: sales.hargaProduk,
    })
  }

  return rows
}

// ─── Stock enrichment (adds brand/stock so they can be filtered & sorted) ─────

function enrichWithStock(rows, stockLookup, category) {
  return rows.map(r => {
    const si = getStockInfo(r.kodeBarang, stockLookup, category)
    const totalHpp = si.hpp * si.stock
    const ssr = r.kuantitas > 0 ? si.stock / r.kuantitas : null
    return { ...r, brand: si.brand, stock: si.stock, unit: si.unit, hasStockData: si.hasData, hpp: si.hpp, totalHpp, ssr }
  })
}

// ─── MP Stock enrichment (stock marketplace dari file gambar SKU) ─────────────
// Ditambahkan sebagai field di tiap baris (bukan dihitung ulang tiap render)
// supaya bisa difilter & diurutkan persis seperti kolom lain.
function enrichWithMpStock(rows, skuIndex) {
  if (!skuIndex) return rows.map(r => ({ ...r, mpStock: null, hasMpStockData: false }))
  return rows.map(r => {
    const entry = lookupSkuEntry(r, skuIndex)
    return { ...r, mpStock: entry?.stock ?? null, hasMpStockData: !!entry }
  })
}

// ─── Sorting ────────────────────────────────────────────────────────────────

const TEXT_SORT_COLS = ['namaBarang', 'kodeBarang', 'brand', 'tipe']

// ─── Kelompokkan per SKU induk (dipakai mode "Per SKU Gabungan") ──────────────
// Logic sama seperti tool Rekap SKU Induk: kode dengan titik (mis. 105132.3.02)
// digabung ke induknya (105132) dan angka-angkanya dijumlahkan; kode TANPA
// titik selalu berdiri sendiri (tipe "tunggal"), tidak pernah ikut digabung.
function groupByParentSku(rows) {
  const groups = {}
  const standalone = []

  rows.forEach(r => {
    const kode = String(r.kodeBarang || '').trim()
    const hasDot = kode.includes('.')

    if (!kode || !hasDot) {
      standalone.push({ ...r, tipe: 'tunggal', variantCount: 1, variantCodes: kode ? [{ kode, namaBarang: r.namaBarang }] : [] })
      return
    }

    const parent = kode.split('.')[0]
    if (!groups[parent]) {
      groups[parent] = {
        kodeBarang: parent, brand: r.brand,
        kuantitas: 0, hargaProduk: 0, stock: 0, totalHpp: 0,
        variantCount: 0, hasStockData: false,
        bestNama: r.namaBarang, bestKuantitas: -1,
        unit: r.unit || '',
        mpStock: 0, hasMpStockData: false,
        variantCodes: [],
      }
    }
    const g = groups[parent]
    g.kuantitas += r.kuantitas
    g.hargaProduk += r.hargaProduk
    g.stock += r.stock || 0
    g.totalHpp += r.totalHpp || 0
    g.variantCount += 1
    g.hasStockData = g.hasStockData || r.hasStockData
    g.variantCodes.push({ kode, namaBarang: r.namaBarang })
    if (r.hasMpStockData) {
      g.mpStock += r.mpStock || 0
      g.hasMpStockData = true
    }
    if (!g.unit && r.unit) g.unit = r.unit
    if (r.kuantitas > g.bestKuantitas) {
      g.bestKuantitas = r.kuantitas
      g.bestNama = r.namaBarang
      g.brand = r.brand
    }
  })

  const groupRows = Object.values(groups).map(g => {
    const hpp = g.stock > 0 ? g.totalHpp / g.stock : 0
    const ssr = g.kuantitas > 0 ? g.stock / g.kuantitas : null
    return {
      kodeBarang: g.kodeBarang, namaBarang: g.bestNama, brand: g.brand,
      kuantitas: g.kuantitas, hargaProduk: g.hargaProduk, stock: g.stock,
      unit: g.unit, hpp, totalHpp: g.totalHpp, ssr, hasStockData: g.hasStockData,
      tipe: 'gabungan', variantCount: g.variantCount,
      mpStock: g.hasMpStockData ? g.mpStock : null, hasMpStockData: g.hasMpStockData,
      variantCodes: g.variantCodes,
    }
  })

  return [...groupRows, ...standalone]
}

function sortRows(rows, sortBy, sortDir = 'desc') {
  const col = sortBy || 'kuantitas'
  const mult = sortDir === 'asc' ? 1 : -1
  const sorted = [...rows]

  sorted.sort((a, b) => {
    if (col === 'namaBarang') {
      return mult * a.namaBarang.localeCompare(b.namaBarang, 'id')
    }
    if (col === 'kodeBarang') {
      if (!a.kodeBarang && b.kodeBarang) return 1
      if (!b.kodeBarang && a.kodeBarang) return -1
      if (!a.kodeBarang && !b.kodeBarang) return 0
      return mult * a.kodeBarang.localeCompare(b.kodeBarang, 'id')
    }
    if (col === 'brand') {
      if (a.brand === '—' && b.brand !== '—') return 1
      if (b.brand === '—' && a.brand !== '—') return -1
      if (a.brand === '—' && b.brand === '—') return 0
      return mult * a.brand.localeCompare(b.brand, 'id')
    }
    if (col === 'tipe') {
      // Cuma ada di mode "Per SKU Gabungan" — kalau kepanggil di mode lain
      // (row.tipe undefined semua), biarkan urutan aslinya (bukan NaN sort).
      return mult * String(a.tipe || '').localeCompare(String(b.tipe || ''), 'id')
    }
    // Numeric columns: kuantitas, hargaProduk, stock, hpp, totalHpp, ssr…
    // Missing/null values (mis. SSR saat terjual = 0) selalu di akhir,
    // terlepas dari arah urutan — bukan ikut kebalik pas toggle ke ascending.
    const av = a[col]
    const bv = b[col]
    const aNull = av == null
    const bNull = bv == null
    if (aNull && bNull) return 0
    if (aNull) return 1
    if (bNull) return -1
    return mult * (av - bv)
  })

  return sorted
}

// ─── Column filter definitions ────────────────────────────────────────────────

const TEXT_OPS = [
  { value: 'contains', label: 'Mengandung' },
  { value: 'not_contains', label: 'Tidak mengandung' },
  { value: 'equals', label: 'Sama dengan' },
  { value: 'not_equals', label: 'Tidak sama dengan' },
  { value: 'starts_with', label: 'Dimulai dengan' },
  { value: 'ends_with', label: 'Diakhiri dengan' },
  { value: 'is_empty', label: 'Kosong' },
  { value: 'is_not_empty', label: 'Tidak kosong' },
]

const NUM_OPS = [
  { value: 'eq', label: '= Sama dengan' },
  { value: 'neq', label: '≠ Tidak sama dengan' },
  { value: 'gt', label: '> Lebih dari' },
  { value: 'gte', label: '≥ Lebih dari atau sama dengan' },
  { value: 'lt', label: '< Kurang dari' },
  { value: 'lte', label: '≤ Kurang dari atau sama dengan' },
  { value: 'between', label: '↔ Di antara' },
]

const EMPTY_COL_FILTER = { op: '', value: '', value2: '' }

// Kolom "Tipe" cuma ada 2 kemungkinan nilai (di mode "Per SKU Gabungan"),
// jadi filternya pakai checklist tetap, bukan pilih kondisi teks segala.
const TIPE_OPTIONS = ['gabungan', 'tunggal']
const TIPE_LABELS = { gabungan: 'Gabungan', tunggal: 'Tunggal' }

function applyColFilter(rows, colFilters) {
  return rows.filter(row => {
    for (const [col, f] of Object.entries(colFilters)) {
      if (!f.op) continue

      // Checklist multi-select (dipakai kolom Brand) — beda struktur dari filter teks/angka biasa
      if (f.op === 'in') {
        if (!f.values || f.values.length === 0) return false // semua di-uncheck = tidak ada yang cocok
        const rawCell = row[col]
        const cell = (!rawCell || rawCell === '—') ? '' : rawCell
        if (!f.values.includes(cell)) return false
        continue
      }

      const noVal = ['is_empty', 'is_not_empty'].includes(f.op)
      if (!noVal && f.value === '' && f.op !== 'between') continue
      if (f.op === 'between' && f.value === '' && f.value2 === '') continue

      if (col === 'namaBarang' || col === 'brand' || col === 'kodeBarang' || col === 'tipe') {
        const rawCell = col === 'namaBarang' ? row.namaBarang
          : col === 'brand' ? row.brand
            : col === 'tipe' ? row.tipe
              : row.kodeBarang
        const cell = (!rawCell || rawCell === '—' ? '' : rawCell).toLowerCase()
        const val = f.value.toLowerCase()
        if (f.op === 'contains' && !cell.includes(val)) return false
        if (f.op === 'not_contains' && cell.includes(val)) return false
        if (f.op === 'equals' && cell !== val) return false
        if (f.op === 'not_equals' && cell === val) return false
        if (f.op === 'starts_with' && !cell.startsWith(val)) return false
        if (f.op === 'ends_with' && !cell.endsWith(val)) return false
        if (f.op === 'is_empty' && cell.trim() !== '') return false
        if (f.op === 'is_not_empty' && cell.trim() === '') return false
      } else {
        const cell = row[col]
        const val = parseFloat(f.value)
        const val2 = parseFloat(f.value2)
        if (f.op === 'eq' && cell !== val) return false
        if (f.op === 'neq' && cell === val) return false
        if (f.op === 'gt' && !(cell > val)) return false
        if (f.op === 'gte' && !(cell >= val)) return false
        if (f.op === 'lt' && !(cell < val)) return false
        if (f.op === 'lte' && !(cell <= val)) return false
        if (f.op === 'between' && !(cell >= val && cell <= val2)) return false
      }
    }
    return true
  })
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function FilterBar({ accounts, filters, onChange, onQuickLast30Days }) {
  const categories = ['Online Underwear', 'Online Sport']

  return (
    <div className="bt-filter-bar">
      <div className="period-picker-group">
        <label className="period-picker-label">Akun</label>
        <select
          className="category-select"
          value={filters.account}
          onChange={e => onChange({ ...filters, account: e.target.value, category: '' })}
        >
          <option value="">Semua akun</option>
          {accounts.map(a => (
            <option key={a} value={a}>{a}</option>
          ))}
        </select>
      </div>

      {!filters.account && (
        <div className="period-picker-group">
          <label className="period-picker-label">Kategori</label>
          <div className="pill-group">
            <button
              className={`pill-btn ${!filters.category ? 'is-active' : ''}`}
              style={!filters.category ? { background: 'var(--ink)', color: '#fff' } : {}}
              onClick={() => onChange({ ...filters, category: '' })}
            >
              Semua
            </button>
            {categories.map(cat => (
              <button
                key={cat}
                className={`pill-btn ${filters.category === cat ? 'is-active' : ''} ${cat.includes('Underwear') ? 'pill-underwear' : 'pill-sport'
                  }`}
                onClick={() => onChange({ ...filters, category: filters.category === cat ? '' : cat })}
              >
                {cat.replace('Online ', '')}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="period-picker-group">
        <label className="period-picker-label">Tanggal mulai</label>
        <input
          type="date"
          className="login-input bt-date-input"
          value={filters.dateFrom}
          onChange={e => onChange({ ...filters, dateFrom: e.target.value })}
        />
      </div>
      <div className="period-picker-group">
        <label className="period-picker-label">Tanggal akhir</label>
        <input
          type="date"
          className="login-input bt-date-input"
          value={filters.dateTo}
          onChange={e => onChange({ ...filters, dateTo: e.target.value })}
        />
      </div>

      <div className="period-picker-group" style={{ justifyContent: 'flex-end' }}>
        <button
          type="button"
          className="pill-btn"
          onClick={onQuickLast30Days}
          title="Gabungkan semua periode & set tanggal ke 30 hari terakhir"
        >
          30 hari terakhir
        </button>
      </div>

      {(filters.account || filters.category || filters.dateFrom || filters.dateTo) && (
        <div className="period-picker-group" style={{ justifyContent: 'flex-end' }}>
          <button
            className="pill-btn"
            onClick={() => onChange({ account: '', category: '', dateFrom: '', dateTo: '' })}
          >
            ✕ Reset filter
          </button>
        </div>
      )}
    </div>
  )
}

function SortIcon({ active, dir }) {
  return (
    <span style={{ marginLeft: 4, opacity: active ? 1 : 0.25, fontSize: 11 }}>
      {active && dir === 'asc' ? '↑' : '↓'}
    </span>
  )
}

function HighlightText({ text, query }) {
  const keywords = query.trim().toLowerCase().split(/\s+/).filter(Boolean)
  if (keywords.length === 0) return <>{text}</>

  const lower = text.toLowerCase()

  // Find every match range (for every keyword), then merge overlapping ones
  // so words like "HOOK" and "HITAM" both get highlighted independently
  // inside "BRA HOOK-01-HITAM".
  const ranges = []
  for (const kw of keywords) {
    let from = 0
    while (from <= lower.length) {
      const idx = lower.indexOf(kw, from)
      if (idx === -1) break
      ranges.push([idx, idx + kw.length])
      from = idx + kw.length
    }
  }
  if (ranges.length === 0) return <>{text}</>

  ranges.sort((a, b) => a[0] - b[0])
  const merged = [ranges[0]]
  for (const [start, end] of ranges.slice(1)) {
    const last = merged[merged.length - 1]
    if (start <= last[1]) last[1] = Math.max(last[1], end)
    else merged.push([start, end])
  }

  const parts = []
  let cursor = 0
  merged.forEach(([start, end], i) => {
    if (start > cursor) parts.push(<span key={`t${i}`}>{text.slice(cursor, start)}</span>)
    parts.push(
      <mark key={`m${i}`} style={{ background: '#fde68a', color: 'inherit', borderRadius: 2, padding: '0 2px' }}>
        {text.slice(start, end)}
      </mark>
    )
    cursor = end
  })
  if (cursor < text.length) parts.push(<span key="tail">{text.slice(cursor)}</span>)

  return <>{parts}</>
}

// ── Column filter popover ─────────────────────────────────────────────────────

function ColFilterPopover({ col, filter, options, onChange, onClose, anchorRef }) {
  const isText = col === 'namaBarang' || col === 'brand' || col === 'kodeBarang' || col === 'tipe'
  const isChecklist = col === 'brand' || col === 'tipe'
  const showChecklistSearch = col === 'brand' // daftar brand bisa panjang; tipe cuma 2 opsi, gak perlu cari
  const optionLabel = col === 'tipe' ? (v => TIPE_LABELS[v] || v) : (v => v)
  const ops = isText ? TEXT_OPS : NUM_OPS
  const ref = useRef(null)
  const [brandSearch, setBrandSearch] = useState('')
  const [pos, setPos] = useState(null)

  // Popover ini di-portal ke document.body dan diposisikan fixed berdasarkan
  // posisi tombol filternya di layar — bukan position:absolute relatif ke <th>.
  // Soalnya <th> ada di dalam .table-scroll yang overflow-x:auto, jadi kalau
  // masih position:absolute, popovernya kepotong di tepi area scroll tabel.
  useLayoutEffect(() => {
    if (!anchorRef.current) return
    const updatePos = () => {
      const rect = anchorRef.current.getBoundingClientRect()
      setPos({ top: rect.bottom + 4, left: rect.left })
    }
    updatePos()
    window.addEventListener('resize', updatePos)
    return () => window.removeEventListener('resize', updatePos)
  }, [anchorRef])

  // Close on outside click
  useEffect(() => {
    function handle(e) {
      if (ref.current && !ref.current.contains(e.target) &&
        anchorRef.current && !anchorRef.current.contains(e.target)) {
        onClose()
      }
    }
    document.addEventListener('mousedown', handle)
    return () => document.removeEventListener('mousedown', handle)
  }, [onClose, anchorRef])

  // Kalau tabel (atau apapun) di-scroll, posisi tombolnya berubah relatif ke
  // viewport, jadi popover fixed-position bakal nyangkut di tempat lama —
  // paling aman langsung ditutup aja daripada ngambang salah tempat.
  useEffect(() => {
    const handleScroll = (e) => {
      if (ref.current && ref.current.contains(e.target)) return // scroll di dalam popover sendiri (list brand) — jangan ditutup
      onClose()
    }
    window.addEventListener('scroll', handleScroll, true)
    return () => window.removeEventListener('scroll', handleScroll, true)
  }, [onClose])

  if (!pos) return null // tunggu posisi anchor didapat dulu (1 tick pertama)

  const basePos = { position: 'fixed', top: pos.top, left: pos.left, zIndex: 500 }

  if (isChecklist) {
    const allOptions = options || []
    // Kalau belum ada filter aktif ('in' belum diset), anggap semua opsi ke-checklist
    const checked = filter.op === 'in' ? (filter.values || []) : allOptions
    const visibleOptions = showChecklistSearch && brandSearch.trim()
      ? allOptions.filter(b => b.toLowerCase().includes(brandSearch.trim().toLowerCase()))
      : allOptions

    const toggleOption = (opt) => {
      const current = filter.op === 'in' ? (filter.values || []) : allOptions
      const next = current.includes(opt) ? current.filter(b => b !== opt) : [...current, opt]
      if (next.length === allOptions.length) {
        onChange(EMPTY_COL_FILTER) // semua ke-checklist lagi = sama saja dengan tidak difilter
      } else {
        onChange({ ...EMPTY_COL_FILTER, op: 'in', values: next })
      }
    }

    return createPortal((
      <div ref={ref} style={{
        ...basePos,
        background: 'var(--surface, #fff)', border: '1px solid var(--border, #ddd)',
        borderRadius: 10, boxShadow: '0 8px 24px rgba(0,0,0,.12)',
        padding: '0.75rem', minWidth: 220,
        display: 'flex', flexDirection: 'column',
      }}>
        {showChecklistSearch && (
          <input
            type="text"
            placeholder="Cari brand…"
            value={brandSearch}
            onChange={e => setBrandSearch(e.target.value)}
            style={{
              width: '100%', padding: '6px 10px', borderRadius: 6,
              border: '1px solid var(--border, #ddd)', background: 'var(--surface, #fff)',
              color: 'var(--ink, #111)', fontSize: 13, marginBottom: 6, boxSizing: 'border-box',
            }}
            autoFocus
          />
        )}

        <div style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
          <button
            onClick={() => onChange(EMPTY_COL_FILTER)}
            style={{ flex: 1, padding: '4px 8px', borderRadius: 6, border: '1px solid var(--border, #ddd)', background: 'none', cursor: 'pointer', fontSize: 11.5, color: 'var(--muted, #888)' }}
          >
            Pilih Semua
          </button>
          <button
            onClick={() => onChange({ ...EMPTY_COL_FILTER, op: 'in', values: [] })}
            style={{ flex: 1, padding: '4px 8px', borderRadius: 6, border: '1px solid var(--border, #ddd)', background: 'none', cursor: 'pointer', fontSize: 11.5, color: 'var(--muted, #888)' }}
          >
            Kosongkan
          </button>
        </div>

        <div style={{ maxHeight: 220, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 3, paddingRight: 2 }}>
          {visibleOptions.length === 0 && (
            <p style={{ fontSize: 12.5, color: 'var(--muted, #888)', margin: '4px 0' }}>Tidak ada opsi yang cocok.</p>
          )}
          {visibleOptions.map(opt => (
            <label key={opt} style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 13, cursor: 'pointer', padding: '2px 2px' }}>
              <input
                type="checkbox"
                checked={checked.includes(opt)}
                onChange={() => toggleOption(opt)}
              />
              {optionLabel(opt)}
            </label>
          ))}
        </div>

        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 10 }}>
          <button
            onClick={onClose}
            style={{
              padding: '5px 12px', borderRadius: 6, border: 'none',
              background: 'var(--ink, #111)', color: '#fff',
              cursor: 'pointer', fontSize: 12, fontWeight: 600,
            }}
          >
            Selesai
          </button>
        </div>
      </div>
    ), document.body)
  }

  const noValueOps = ['is_empty', 'is_not_empty']
  const isBetween = filter.op === 'between'
  const hideInput = noValueOps.includes(filter.op)

  const inputStyle = {
    width: '100%', padding: '6px 10px', borderRadius: 6,
    border: '1px solid var(--border, #ddd)',
    background: 'var(--surface, #fff)',
    color: 'var(--ink, #111)',
    fontSize: 13, marginTop: 6, boxSizing: 'border-box',
  }

  return createPortal((
    <div ref={ref} style={{
      ...basePos,
      background: 'var(--surface, #fff)',
      border: '1px solid var(--border, #ddd)',
      borderRadius: 10,
      boxShadow: '0 8px 24px rgba(0,0,0,.12)',
      padding: '0.85rem',
      minWidth: 240,
      display: 'flex',
      flexDirection: 'column',
    }}>
      {/* Op selector */}
      <select
        value={filter.op}
        onChange={e => onChange({ ...filter, op: e.target.value, value: '', value2: '' })}
        style={{ ...inputStyle, marginTop: 0 }}
      >
        <option value="">— Pilih kondisi —</option>
        {ops.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>

      {/* Value input(s) */}
      {filter.op && !hideInput && (
        <>
          <input
            type={isText ? 'text' : 'number'}
            placeholder={isBetween ? 'Nilai minimum' : 'Nilai'}
            value={filter.value}
            onChange={e => onChange({ ...filter, value: e.target.value })}
            style={inputStyle}
            autoFocus
          />
          {isBetween && (
            <input
              type="number"
              placeholder="Nilai maksimum"
              value={filter.value2}
              onChange={e => onChange({ ...filter, value2: e.target.value })}
              style={inputStyle}
            />
          )}
        </>
      )}

      {/* Footer buttons */}
      <div style={{ display: 'flex', gap: 6, marginTop: 10, justifyContent: 'flex-end' }}>
        <button
          onClick={() => { onChange(EMPTY_COL_FILTER); onClose() }}
          style={{
            padding: '5px 12px', borderRadius: 6, border: '1px solid var(--border, #ddd)',
            background: 'none', cursor: 'pointer', fontSize: 12,
            color: 'var(--muted, #888)',
          }}
        >
          Hapus
        </button>
        <button
          onClick={onClose}
          style={{
            padding: '5px 12px', borderRadius: 6, border: 'none',
            background: 'var(--ink, #111)', color: '#fff',
            cursor: 'pointer', fontSize: 12, fontWeight: 600,
          }}
        >
          Terapkan
        </button>
      </div>
    </div>
  ), document.body)
}

// ── Column header with sort + filter ─────────────────────────────────────────

function ColHeader({ col, label, align = 'left', sortBy, sortDir, onSortChange, colFilters, onColFilterChange, brandOptions }) {
  const [open, setOpen] = useState(false)
  const btnRef = useRef(null)
  const filter = colFilters[col] || EMPTY_COL_FILTER
  const isActive = filter.op === 'in'
    ? !!(filter.values && filter.values.length > 0)
    : !!(filter.op && (
      ['is_empty', 'is_not_empty'].includes(filter.op) || filter.value !== ''
    ))

  return (
    <th
      style={{
        textAlign: align,
        whiteSpace: 'nowrap',
        position: 'relative',
        userSelect: 'none',
      }}
    >
      {/* Sort trigger (whole cell minus filter btn) */}
      <span
        onClick={() => onSortChange(col)}
        style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 2 }}
        title={`Urutkan berdasarkan ${label}`}
      >
        {align === 'right' && <SortIcon active={sortBy === col} dir={sortDir} />}
        {label}
        {align === 'left' && <SortIcon active={sortBy === col} dir={sortDir} />}
      </span>

      {/* Filter button */}
      <button
        ref={btnRef}
        onClick={e => { e.stopPropagation(); setOpen(v => !v) }}
        title="Filter kolom"
        style={{
          marginLeft: 5,
          padding: '1px 5px',
          borderRadius: 4,
          border: `1px solid ${isActive ? 'var(--accent-2, #6366f1)' : 'var(--border, #ddd)'}`,
          background: isActive ? 'var(--accent-2, #6366f1)' : 'transparent',
          color: isActive ? '#fff' : 'var(--muted, #888)',
          cursor: 'pointer',
          fontSize: 11,
          lineHeight: 1.4,
          verticalAlign: 'middle',
        }}
      >
        {isActive ? '▼●' : '▼'}
      </button>

      {/* Popover */}
      {open && (
        <ColFilterPopover
          col={col}
          filter={filter}
          options={col === 'tipe' ? TIPE_OPTIONS : brandOptions}
          onChange={f => onColFilterChange(col, f)}
          onClose={() => setOpen(false)}
          anchorRef={btnRef}
        />
      )}
    </th>
  )
}

// ── Catatan per baris (popover edit, mirip komentar cell Excel) ────────────────

function formatNoteTimestamp(iso) {
  if (!iso) return ''
  try {
    return new Date(iso).toLocaleString('id-ID', {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit',
    })
  } catch {
    return ''
  }
}

function NoteEditorPopover({ initialText, updatedAt, saving, childNotes, onSave, onDelete, onClose, anchorRef }) {
  const [text, setText] = useState(initialText || '')
  const ref = useRef(null)
  const textareaRef = useRef(null)
  const [pos, setPos] = useState(null)
  const hasChildNotes = childNotes && childNotes.length > 0

  useLayoutEffect(() => {
    if (!anchorRef.current) return
    const rect = anchorRef.current.getBoundingClientRect()
    // Coba taruh di kanan tombol; kalau kepotong tepi kanan layar, taruh di kiri.
    const width = 300
    const left = rect.right + width + 8 > window.innerWidth
      ? Math.max(8, rect.left - width - 8)
      : rect.right + 8
    setPos({ top: Math.min(rect.top, window.innerHeight - (hasChildNotes ? 340 : 220)), left })
  }, [anchorRef, hasChildNotes])

  useEffect(() => {
    textareaRef.current?.focus()
  }, [])

  useEffect(() => {
    function handle(e) {
      if (ref.current && !ref.current.contains(e.target) &&
        anchorRef.current && !anchorRef.current.contains(e.target)) {
        onClose()
      }
    }
    document.addEventListener('mousedown', handle)
    return () => document.removeEventListener('mousedown', handle)
  }, [onClose, anchorRef])

  useEffect(() => {
    const handleScroll = (e) => {
      if (ref.current && ref.current.contains(e.target)) return
      onClose()
    }
    window.addEventListener('scroll', handleScroll, true)
    return () => window.removeEventListener('scroll', handleScroll, true)
  }, [onClose])

  if (!pos) return null

  const handleSave = async () => {
    const ok = await onSave(text)
    if (ok) onClose()
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Escape') onClose()
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) handleSave()
  }

  return createPortal((
    <div
      ref={ref}
      style={{
        position: 'fixed', top: pos.top, left: pos.left, zIndex: 500,
        background: 'var(--surface, #fff)', border: '1px solid var(--border, #ddd)',
        borderRadius: 10, boxShadow: '0 8px 24px rgba(0,0,0,.16)',
        padding: '0.75rem', width: 300, boxSizing: 'border-box',
        display: 'flex', flexDirection: 'column', gap: 8,
        maxHeight: '70vh', overflowY: 'auto',
      }}
    >
      {hasChildNotes && (
        <div style={{
          display: 'flex', flexDirection: 'column', gap: 6,
          paddingBottom: 8, borderBottom: '1px solid var(--border, #ddd)',
        }}>
          <p className="muted" style={{ margin: 0, fontSize: 11.5, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.3 }}>
            Catatan dari varian ({childNotes.length})
          </p>
          {childNotes.map(cn => (
            <div key={cn.kodeBarang} style={{
              background: 'var(--paper, #f6f4ef)', borderRadius: 6, padding: '6px 8px',
            }}>
              <p className="muted" style={{ margin: '0 0 2px', fontSize: 10.5, fontWeight: 600 }}>{cn.namaBarang || cn.kodeBarang}</p>
              <p style={{ margin: 0, fontSize: 12.5, whiteSpace: 'pre-wrap' }}>{cn.text}</p>
              <p className="muted" style={{ margin: '2px 0 0', fontSize: 10.5 }}>{formatNoteTimestamp(cn.updatedAt)}</p>
            </div>
          ))}
          <p className="muted" style={{ margin: 0, fontSize: 11 }}>
            Catatan varian diedit dari tampilan "Per Varian".
          </p>
        </div>
      )}

      <p className="muted" style={{ margin: 0, fontSize: 11.5, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.3 }}>
        {hasChildNotes ? 'Catatan SKU induk' : 'Catatan'}
      </p>
      <textarea
        ref={textareaRef}
        value={text}
        onChange={e => setText(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Tulis catatan untuk produk ini…"
        maxLength={2000}
        rows={5}
        style={{
          width: '100%', resize: 'vertical', boxSizing: 'border-box',
          padding: '8px 10px', borderRadius: 6,
          border: '1px solid var(--border, #ddd)', background: 'var(--surface, #fff)',
          color: 'var(--ink, #111)', fontSize: 13, fontFamily: 'inherit',
        }}
      />
      {updatedAt && (
        <p className="muted" style={{ margin: 0, fontSize: 11.5 }}>
          Terakhir diedit: {formatNoteTimestamp(updatedAt)}
        </p>
      )}
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 6 }}>
        {initialText
          ? (
            <button
              type="button"
              onClick={async () => { const ok = await onDelete(); if (ok) onClose() }}
              disabled={saving}
              style={{
                padding: '5px 10px', borderRadius: 6, border: '1px solid var(--border, #ddd)',
                background: 'transparent', color: 'var(--accent, #D85A30)',
                cursor: saving ? 'default' : 'pointer', fontSize: 12,
              }}
            >
              Hapus
            </button>
          )
          : <span />}
        <div style={{ display: 'flex', gap: 6 }}>
          <button
            type="button"
            onClick={onClose}
            disabled={saving}
            style={{
              padding: '5px 10px', borderRadius: 6, border: '1px solid var(--border, #ddd)',
              background: 'transparent', color: 'var(--ink, #111)',
              cursor: saving ? 'default' : 'pointer', fontSize: 12,
            }}
          >
            Batal
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            style={{
              padding: '5px 12px', borderRadius: 6, border: 'none',
              background: 'var(--ink, #111)', color: '#fff',
              cursor: saving ? 'default' : 'pointer', fontSize: 12, fontWeight: 600,
            }}
          >
            {saving ? 'Menyimpan…' : 'Simpan'}
          </button>
        </div>
      </div>
    </div>
  ), document.body)
}

function NoteCell({ kodeBarang, note, childNotes, saving, onSave, onDelete }) {
  const [open, setOpen] = useState(false)
  const btnRef = useRef(null)
  const hasOwnNote = !!note?.text
  const hasChildNotes = childNotes && childNotes.length > 0
  const hasNote = hasOwnNote || hasChildNotes

  if (!kodeBarang) {
    return <td style={{ textAlign: 'center' }}><span className="muted">—</span></td>
  }

  const titleParts = []
  if (hasOwnNote) titleParts.push(`${note.text}\n(diedit: ${formatNoteTimestamp(note.updatedAt)})`)
  if (hasChildNotes) {
    titleParts.push(
      `Catatan dari ${childNotes.length} varian:\n` +
      childNotes.map(cn => `• [${cn.namaBarang || cn.kodeBarang}] ${cn.text}`).join('\n')
    )
  }
  const title = titleParts.length ? titleParts.join('\n\n') : 'Tambah catatan'

  return (
    <td style={{ textAlign: 'center', position: 'relative' }}>
      <button
        ref={btnRef}
        type="button"
        onClick={() => setOpen(v => !v)}
        title={title}
        style={{
          border: 'none', background: 'transparent', cursor: 'pointer',
          fontSize: 15, lineHeight: 1, padding: 4, borderRadius: 6,
          opacity: hasNote ? 1 : 0.35, position: 'relative',
        }}
      >
        {hasOwnNote ? '📝' : (hasChildNotes ? '🗂️' : '🗒️')}
        {hasChildNotes && (
          <span style={{
            position: 'absolute', top: -2, right: -2, minWidth: 13, height: 13,
            borderRadius: 7, background: 'var(--primary, #3B3A8C)', color: '#fff',
            fontSize: 9, fontWeight: 700, lineHeight: '13px', padding: '0 3px',
          }}>
            {childNotes.length}
          </span>
        )}
      </button>
      {open && (
        <NoteEditorPopover
          initialText={note?.text || ''}
          updatedAt={note?.updatedAt}
          saving={saving}
          childNotes={childNotes}
          onSave={(text) => onSave(kodeBarang, text)}
          onDelete={() => onDelete(kodeBarang)}
          onClose={() => setOpen(false)}
          anchorRef={btnRef}
        />
      )}
    </td>
  )
}

// ── Modal preview gambar produk (klik thumbnail di kolom Gambar) ───────────────

function ImagePreviewModal({ url, alt, onClose }) {
  useEffect(() => {
    const handleKey = (e) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', handleKey)
    return () => document.removeEventListener('keydown', handleKey)
  }, [onClose])

  return createPortal((
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 1000,
        background: 'rgba(0,0,0,.65)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '2rem',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: 'var(--surface, #fff)', borderRadius: 12, padding: '1rem',
          maxWidth: 'min(90vw, 640px)', maxHeight: '90vh',
          display: 'flex', flexDirection: 'column', gap: 10,
          boxShadow: '0 20px 60px rgba(0,0,0,.35)',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
          <p style={{ margin: 0, fontWeight: 600, fontSize: 14 }}>{alt}</p>
          <button
            type="button"
            onClick={onClose}
            style={{
              border: 'none', background: 'transparent', cursor: 'pointer',
              fontSize: 20, lineHeight: 1, padding: 4, color: 'var(--ink, #111)',
            }}
            aria-label="Tutup"
          >
            ×
          </button>
        </div>
        <img
          src={url}
          alt={alt}
          style={{
            maxWidth: '100%', maxHeight: '75vh', width: 'auto', height: 'auto',
            objectFit: 'contain', borderRadius: 8, display: 'block', margin: '0 auto',
          }}
        />
      </div>
    </div>
  ), document.body)
}

// ── Main table component ──────────────────────────────────────────────────────

const PAGE_SIZE_OPTIONS = [
  { value: 50, label: '50' },
  { value: 100, label: '100' },
  { value: 200, label: '200' },
  { value: 'all', label: 'Semua' },
]

function Pagination({ page, totalPages, pageSize, onPageChange, onPageSizeChange, totalRows }) {
  const startRow = totalRows === 0 ? 0 : (page - 1) * (pageSize === 'all' ? totalRows : pageSize) + 1
  const endRow = pageSize === 'all' ? totalRows : Math.min(page * pageSize, totalRows)

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      flexWrap: 'wrap', gap: '0.6rem', marginTop: '0.75rem',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--ink-muted)' }}>
        <span>Baris per halaman</span>
        <select
          value={pageSize}
          onChange={e => {
            const raw = e.target.value
            onPageSizeChange(raw === 'all' ? 'all' : Number(raw))
          }}
          style={{
            padding: '4px 8px', borderRadius: 6, border: '1px solid var(--border, #ddd)',
            background: 'var(--surface, #fff)', fontSize: 13, cursor: 'pointer',
          }}
        >
          {PAGE_SIZE_OPTIONS.map(opt => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
        <span className="mono">
          {totalRows === 0 ? '0' : `${startRow}–${endRow}`} dari {totalRows}
        </span>
      </div>

      {pageSize !== 'all' && totalPages > 1 && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <button
            onClick={() => onPageChange(1)}
            disabled={page <= 1}
            style={pagerBtnStyle(page <= 1)}
            title="Halaman pertama"
          >«</button>
          <button
            onClick={() => onPageChange(page - 1)}
            disabled={page <= 1}
            style={pagerBtnStyle(page <= 1)}
            title="Sebelumnya"
          >‹</button>
          <span className="mono" style={{ fontSize: 13, padding: '0 4px' }}>
            {page} / {totalPages}
          </span>
          <button
            onClick={() => onPageChange(page + 1)}
            disabled={page >= totalPages}
            style={pagerBtnStyle(page >= totalPages)}
            title="Berikutnya"
          >›</button>
          <button
            onClick={() => onPageChange(totalPages)}
            disabled={page >= totalPages}
            style={pagerBtnStyle(page >= totalPages)}
            title="Halaman terakhir"
          >»</button>
        </div>
      )}
    </div>
  )
}

function pagerBtnStyle(disabled) {
  return {
    padding: '4px 10px', borderRadius: 6, border: '1px solid var(--border, #ddd)',
    background: disabled ? 'var(--surface-2, #f5f5f5)' : 'var(--surface, #fff)',
    color: disabled ? 'var(--ink-muted)' : 'var(--ink)',
    cursor: disabled ? 'default' : 'pointer', fontSize: 14, lineHeight: 1,
  }
}

function ExportSplitBtnSm({ allRows, pageRows, exportOptions }) {
  const [open, setOpen] = useState(false)
  const wrapRef = useRef(null)

  useEffect(() => {
    if (!open) return
    function handleClick(e) {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [open])

  return (
    <div className="export-split-wrap" ref={wrapRef}>
      <button
        className="btn-export-main sm"
        onClick={() => { exportBarangTerlaris(allRows, exportOptions); setOpen(false) }}
      >
        ↓ Ekspor Excel
      </button>
      <button
        className="btn-export-caret sm"
        onClick={() => setOpen(v => !v)}
        title="Pilih format ekspor"
        aria-label="Pilih format ekspor"
      >
        ▾
      </button>
      {open && (
        <div className="export-dropdown-menu">
          <button
            className="export-dropdown-item"
            onClick={() => { exportBarangTerlaris(allRows, exportOptions); setOpen(false) }}
          >
            <span className="export-item-label">📋 Semua hasil filter</span>
            <span className="export-item-sub">Ekspor seluruh {allRows.length} baris yang difilter</span>
          </button>
          <button
            className="export-dropdown-item"
            onClick={() => {
              exportBarangTerlaris(pageRows, { ...exportOptions, filterDesc: (exportOptions.filterDesc ? exportOptions.filterDesc + ' · ' : '') + `Halaman ini (${pageRows.length} baris)` })
              setOpen(false)
            }}
          >
            <span className="export-item-label">🖥️ Halaman ini saja</span>
            <span className="export-item-sub">Hanya {pageRows.length} baris yang tampil di layar</span>
          </button>
        </div>
      )}
    </div>
  )
}

function BestSellerTable({
  rows, loading, sortBy, sortDir, onSortChange,
  searchQuery, onSearchChange,
  colFilters, onColFilterChange,
  stockLookup, brandOptions,
  groupMode, onGroupModeChange,
  imageIndex, imageMeta, imageError, imageUploadError, imageUploading,
  onImageFile, showImages, onToggleShowImages,
  notes, notesError, savingNoteFor, onSaveNote, onDeleteNote,
  exportOptions,
  onPageRowsChange,
}) {
  const totalKuantitas = rows.reduce((s, r) => s + r.kuantitas, 0)
  const totalHargaProduk = rows.reduce((s, r) => s + r.hargaProduk, 0)
  const totalHpp = rows.reduce((s, r) => s + (r.totalHpp || 0), 0)
  const totalStockPcs = rows.reduce((s, r) => s + (r.stock || 0), 0)
  const totalHppTerjual = rows.reduce((s, r) => s + (r.hpp || 0) * (r.kuantitas || 0), 0) // Σ (HPP PCS × Terjual)
  const ssrGrand = totalKuantitas > 0 ? totalStockPcs / totalKuantitas : null      // Stock PCS / Terjual
  const ssrHppGrand = totalHppTerjual > 0 ? totalHpp / totalHppTerjual : null       // Total HPP / Σ(HPP × Terjual)
  const hasStock = stockLookup !== null
  const hasImages = imageMeta?.count > 0
  const showImageCol = showImages && hasImages

  const colHeaderProps = { sortBy, sortDir, onSortChange, colFilters, onColFilterChange, brandOptions }

  const imageInputRef = useRef(null)
  const [previewImage, setPreviewImage] = useState(null) // { url, alt } | null

  // ── Pagination (client-side; slices the already-filtered `rows`) ──
  const [pageSize, setPageSize] = useState(50)
  const [page, setPage] = useState(1)

  // Reset to page 1 whenever the underlying row set changes (new filter, search, sort…)
  useEffect(() => {
    setPage(1)
  }, [rows])

  const totalPages = pageSize === 'all' ? 1 : Math.max(1, Math.ceil(rows.length / pageSize))
  const safePage = Math.min(page, totalPages)
  const pageRows = pageSize === 'all'
    ? rows
    : rows.slice((safePage - 1) * pageSize, safePage * pageSize)

  // Notify parent of current page rows so the top export button can use them
  useEffect(() => {
    if (onPageRowsChange) onPageRowsChange(pageRows)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageRows, onPageRowsChange])

  return (
    <>
      {/* ── Mode tampilan: per varian vs per SKU induk (gabungan) ── */}
      <div style={{ display: 'flex', gap: 6, marginBottom: '0.75rem' }}>
        <button
          type="button"
          className="pill-btn"
          onClick={() => onGroupModeChange('variant')}
          title="Tampilkan setiap varian SKU sebagai baris terpisah (perilaku biasa)"
          style={groupMode === 'variant' ? { background: 'var(--primary, #3B3A8C)', color: '#fff', borderColor: 'transparent' } : undefined}
        >
          Per Varian
        </button>
        <button
          type="button"
          className="pill-btn"
          onClick={() => onGroupModeChange('induk')}
          title="Gabungkan varian dengan kode yang sama sebelum titik (mis. 105132.3.02) ke SKU induknya (105132). Kode tanpa titik tetap tampil sendiri."
          style={groupMode === 'induk' ? { background: 'var(--primary, #3B3A8C)', color: '#fff', borderColor: 'transparent' } : undefined}
        >
          Per SKU Gabungan
        </button>
      </div>

      {/* ── Upload gambar SKU + toggle tampilkan gambar ── */}
      <div style={{ display: 'flex', gap: 6, marginBottom: '0.75rem', flexWrap: 'wrap', alignItems: 'center' }}>
        <input
          ref={imageInputRef}
          type="file"
          accept=".xlsx,.xls"
          style={{ display: 'none' }}
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) onImageFile(file)
            e.target.value = '' // biar bisa upload file yang sama lagi kalau perlu
          }}
        />
        <button
          type="button"
          className="pill-btn"
          onClick={() => imageInputRef.current?.click()}
          disabled={imageUploading}
          title="Upload file .xlsx berisi kolom SKU dan IMAGE (link CDN gambar produk)"
        >
          {imageUploading ? 'Mengupload…' : (hasImages ? '📤 Ganti File Gambar SKU' : '📤 Upload Gambar SKU')}
        </button>
        <button
          type="button"
          className="pill-btn"
          onClick={onToggleShowImages}
          disabled={!hasImages}
          title={!hasImages ? 'Upload file gambar SKU dulu' : (showImages ? 'Sembunyikan kolom gambar' : 'Tampilkan kolom gambar')}
          style={showImages ? { background: 'var(--primary, #3B3A8C)', color: '#fff', borderColor: 'transparent' } : undefined}
        >
          {showImages ? '🖼️ Sembunyikan Gambar' : '🖼️ Tampilkan Gambar'}
        </button>
        {hasImages && (
          <span className="muted" style={{ fontSize: 12.5 }}>
            {imageMeta.count.toLocaleString('id-ID')} SKU tersimpan di server
            {imageMeta.savedAt ? ` · diupdate ${new Date(imageMeta.savedAt).toLocaleString('id-ID')}` : ''}
          </span>
        )}
      </div>
      {imageError && (
        <p className="upload-error" style={{ marginTop: 0, marginBottom: '0.75rem' }}>⚠️ {imageError}</p>
      )}
      {imageUploadError && (
        <p className="upload-error" style={{ marginTop: 0, marginBottom: '0.75rem' }}>⚠️ {imageUploadError}</p>
      )}
      {notesError && (
        <p className="upload-error" style={{ marginTop: 0, marginBottom: '0.75rem' }}>⚠️ {notesError}</p>
      )}

      {/* ── Search bar ── */}
      <div style={{ marginBottom: '0.75rem', position: 'relative' }}>
        <span style={{
          position: 'absolute', left: '0.75rem', top: '50%',
          transform: 'translateY(-50%)', fontSize: 15,
          color: 'var(--muted, #888)', pointerEvents: 'none',
        }}>🔍</span>
        <input
          type="text"
          className="login-input"
          placeholder="Cari nama barang…"
          value={searchQuery}
          onChange={e => onSearchChange(e.target.value)}
          style={{ paddingLeft: '2.25rem', paddingRight: searchQuery ? '2.25rem' : undefined }}
        />
        {searchQuery && (
          <button
            onClick={() => onSearchChange('')}
            style={{
              position: 'absolute', right: '0.6rem', top: '50%',
              transform: 'translateY(-50%)', background: 'none', border: 'none',
              cursor: 'pointer', fontSize: 16, color: 'var(--muted, #888)',
              lineHeight: 1, padding: '0 4px',
            }}
            title="Hapus pencarian"
          >✕</button>
        )}
      </div>

      {loading && <p className="loading-text">Memuat data…</p>}

      {!loading && (
        <>
          {/* ── Grand total summary ── */}
          <div style={{ display: 'flex', gap: '1rem', marginBottom: '0.75rem', flexWrap: 'wrap' }}>
            <div style={{
              flex: 1, minWidth: 140,
              background: 'var(--surface-2, #f5f5f5)', borderRadius: 8, padding: '0.6rem 1rem',
            }}>
              <p className="muted" style={{ fontSize: 12, margin: 0 }}>Total Terjual</p>
              <p className="mono" style={{ fontSize: 18, fontWeight: 700, margin: '2px 0 0' }}>
                {totalKuantitas.toLocaleString('id-ID')}
              </p>
            </div>
            <div style={{
              flex: 1, minWidth: 140,
              background: 'var(--surface-2, #f5f5f5)', borderRadius: 8, padding: '0.6rem 1rem',
            }}>
              <p className="muted" style={{ fontSize: 12, margin: 0 }}>Total Harga Produk</p>
              <p className="mono" style={{ fontSize: 18, fontWeight: 700, margin: '2px 0 0' }}>
                {formatRupiah(totalHargaProduk)}
              </p>
            </div>
            {hasStock && (
              <>
                <div style={{
                  flex: 1, minWidth: 140,
                  background: 'var(--surface-2, #f5f5f5)', borderRadius: 8, padding: '0.6rem 1rem',
                }}>
                  <p className="muted" style={{ fontSize: 12, margin: 0 }}>Total HPP</p>
                  <p className="mono" style={{ fontSize: 18, fontWeight: 700, margin: '2px 0 0' }}>
                    {formatRupiah(totalHpp)}
                  </p>
                </div>
                <div style={{
                  flex: 1, minWidth: 140,
                  background: 'var(--surface-2, #f5f5f5)', borderRadius: 8, padding: '0.6rem 1rem',
                }}>
                  <p className="muted" style={{ fontSize: 12, margin: 0 }}>Stock PCS</p>
                  <p className="mono" style={{ fontSize: 18, fontWeight: 700, margin: '2px 0 0' }}>
                    {totalStockPcs.toLocaleString('id-ID')}
                  </p>
                </div>
                <div style={{
                  flex: 1, minWidth: 140,
                  background: 'var(--surface-2, #f5f5f5)', borderRadius: 8, padding: '0.6rem 1rem',
                }}>
                  <p className="muted" style={{ fontSize: 12, margin: 0 }}>SSR</p>
                  <p className="mono" style={{ fontSize: 18, fontWeight: 700, margin: '2px 0 0' }}>
                    {ssrGrand != null ? ssrGrand.toFixed(2) : '—'}
                  </p>
                </div>
                <div style={{
                  flex: 1, minWidth: 140,
                  background: 'var(--surface-2, #f5f5f5)', borderRadius: 8, padding: '0.6rem 1rem',
                }}>
                  <p className="muted" style={{ fontSize: 12, margin: 0 }}>SSR (HPP)</p>
                  <p className="mono" style={{ fontSize: 18, fontWeight: 700, margin: '2px 0 0' }}>
                    {ssrHppGrand != null ? ssrHppGrand.toFixed(2) : '—'}
                  </p>
                </div>
              </>
            )}
          </div>

          {/* ── Search result count ── */}
          {searchQuery.trim() && (
            <p className="period-note" style={{ marginBottom: '0.5rem', marginTop: 0 }}>
              Menampilkan {rows.length} produk untuk pencarian &ldquo;{searchQuery}&rdquo;
            </p>
          )}

          {!hasStock && (
            <p className="period-note" style={{ marginBottom: '0.5rem', color: 'var(--ink-muted)' }}>
              ℹ️ Data stock belum diupload. Upload file stock di halaman Admin untuk melihat kolom Brand dan Stock.
            </p>
          )}

          {hasStock && (
            <p className="period-note" style={{ fontSize: '1rem', fontWeight: 'bold', marginBottom: '0.75rem', display: 'flex', flexWrap: 'wrap', gap: '0.4rem 1rem', alignItems: 'center' }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                <span style={{ width: 24, height: 24, borderRadius: 5, background: 'rgb(255, 162, 162)', display: 'inline-block' }} />
                SSR &lt; 1 = stock tidak cukup untuk 1 bulan.
              </span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                <span style={{ width: 24, height: 24, borderRadius: 5, background: 'rgb(255, 235, 156)', display: 'inline-block' }} />
                SSR 1 – 2 = stock hanya cukup untuk 1-2 bulan, segera restock.
              </span>
            </p>
          )}

          {/* ── Table ── */}
          <div className="table-scroll" style={{ overflowX: 'auto' }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th style={{ width: 40 }} title="Catatan">📝</th>
                  <th style={{ width: 44 }}>#</th>
                  <ColHeader col="kodeBarang" label="Kode Barang" align="left"  {...colHeaderProps} />
                  {groupMode === 'induk' && <ColHeader col="tipe" label="Tipe" align="left" {...colHeaderProps} />}
                  {showImageCol && <th style={{ width: 60, textAlign: 'center' }}>Gambar</th>}
                  <ColHeader col="namaBarang" label="Nama Barang" align="left"  {...colHeaderProps} />
                  {hasStock && <ColHeader col="brand" label="Brand" align="left"  {...colHeaderProps} />}
                  <ColHeader col="kuantitas" label="Terjual" align="right" {...colHeaderProps} />
                  <ColHeader col="hargaProduk" label="Harga Produk" align="right" {...colHeaderProps} />
                  {hasStock && <ColHeader col="stock" label="Stock" align="right" {...colHeaderProps} />}
                  {showImageCol && <ColHeader col="mpStock" label="MP Stock" align="right" {...colHeaderProps} />}
                  {hasStock && <ColHeader col="unit" label="Unit" align="left" {...colHeaderProps} />}
                  {hasStock && <ColHeader col="hpp" label="HPP PCS" align="right" {...colHeaderProps} />}
                  {hasStock && <ColHeader col="totalHpp" label="Total HPP" align="right" {...colHeaderProps} />}
                  {hasStock && <ColHeader col="ssr" label="SSR" align="right" {...colHeaderProps} />}
                </tr>
              </thead>
              <tbody>
                {pageRows.length === 0 && (
                  <tr>
                    <td colSpan={(hasStock ? 10 : 5) + (groupMode === 'induk' ? 1 : 0) + (showImageCol ? 2 : 0) + 1} style={{ textAlign: 'center', padding: '2.5rem 1rem' }}>
                      <p className="upload-title" style={{ margin: '0 0 4px' }}>Tidak ada produk ditemukan</p>
                      <p className="upload-sub" style={{ margin: 0 }}>
                        {searchQuery
                          ? `Tidak ada produk yang cocok dengan "${searchQuery}". Coba kata kunci lain.`
                          : 'Coba ubah filter kolom, tanggal, akun, atau kategori — termasuk checklist Brand, kalau semua brand-nya sedang dikosongkan.'}
                      </p>
                    </td>
                  </tr>
                )}
                {pageRows.map((row) => {
                  const si = hasStock ? { brand: row.brand, stock: row.stock, hasData: row.hasStockData } : null
                  const lowSsr = hasStock && row.ssr != null && row.ssr < 1
                  const restockSoonSsr = hasStock && row.ssr != null && row.ssr >= 1 && row.ssr <= 2
                  const rowStyle = lowSsr
                    ? { background: 'rgb(255, 162, 162)' }
                    : restockSoonSsr
                      ? { background: 'rgb(255, 235, 156)' }
                      : undefined
                  const rowTitle = lowSsr
                    ? 'SSR < 1 — stock lebih sedikit dari yang terjual'
                    : restockSoonSsr
                      ? 'SSR 1–2 — stock menipis, pertimbangkan untuk restock'
                      : undefined
                  // Di tampilan "Per SKU Gabungan", tarik & tampilkan juga catatan yang
                  // sebelumnya ditulis per-varian (di tampilan "Per Varian") — supaya
                  // tidak "hilang"/ketutup di balik baris gabungan.
                  const childNotes = (groupMode === 'induk' && row.variantCodes && row.variantCodes.length > 0)
                    ? row.variantCodes
                      .filter(v => v.kode !== row.kodeBarang)
                      .map(v => ({ kodeBarang: v.kode, namaBarang: v.namaBarang, ...notes?.[v.kode] }))
                      .filter(cn => cn.text)
                    : []
                  return (
                    <tr
                      key={row.kodeBarang ? `k-${row.kodeBarang}-${row.tipe || 'v'}` : `r-${row.rank}`}
                      style={rowStyle}
                      title={rowTitle}
                    >
                      <NoteCell
                        kodeBarang={row.kodeBarang}
                        note={notes?.[row.kodeBarang]}
                        childNotes={childNotes}
                        saving={savingNoteFor === row.kodeBarang}
                        onSave={onSaveNote}
                        onDelete={onDeleteNote}
                      />
                      <td className="mono" style={{ textAlign: 'center' }}>{row.rank}</td>
                      <td className="mono" style={{ whiteSpace: 'nowrap' }}>
                        {row.kodeBarang || '—'}
                      </td>
                      {groupMode === 'induk' && (
                        <td style={{ whiteSpace: 'nowrap' }}>
                          {row.tipe === 'gabungan'
                            ? <span className="badge-brand" style={{ background: 'var(--surface-2, #f0eefc)' }}>Gabungan ({row.variantCount}x)</span>
                            : <span className="mono" style={{ fontSize: 12.5 }}>Tunggal</span>}
                        </td>
                      )}
                      {showImageCol && (() => {
                        const entry = lookupSkuEntry(row, imageIndex)
                        const proxiedUrl = entry?.image ? `/api/image-proxy?url=${encodeURIComponent(entry.image)}` : null
                        return (
                          <td style={{ textAlign: 'center' }}>
                            {proxiedUrl
                              ? <img
                                  src={proxiedUrl}
                                  alt={row.namaBarang || row.kodeBarang || ''}
                                  style={{ height: 40, width: 'auto', borderRadius: 4, objectFit: 'cover', verticalAlign: 'middle', cursor: 'pointer' }}
                                  loading="lazy"
                                  title="Klik untuk memperbesar"
                                  onClick={() => setPreviewImage({ url: proxiedUrl, alt: row.namaBarang || row.kodeBarang || '' })}
                                  onError={(e) => { e.currentTarget.style.visibility = 'hidden' }}
                                />
                              : <span className="muted">—</span>}
                          </td>
                        )
                      })()}
                      <td style={{ fontWeight: 500 }}>
                        <HighlightText text={row.namaBarang} query={searchQuery} />
                      </td>
                      {hasStock && (
                        <td style={{ whiteSpace: 'nowrap' }}>
                          {si.brand !== '—'
                            ? <span className="badge-brand">{si.brand}</span>
                            : <span className="muted">—</span>}
                        </td>
                      )}
                      <td className="mono" style={{ textAlign: 'right' }}>
                        {row.kuantitas.toLocaleString('id-ID')}
                      </td>
                      <td className="mono" style={{ textAlign: 'right' }}>
                        {formatRupiah(row.hargaProduk)}
                      </td>
                      {hasStock && (
                        <td className="mono" style={{ textAlign: 'right' }}>
                          {si.hasData
                            ? <span style={{ color: si.stock === 0 ? 'var(--accent, #D85A30)' : 'inherit' }}>
                              {si.stock.toLocaleString('id-ID')}
                            </span>
                            : <span className="muted">0</span>}
                        </td>
                      )}
                      {showImageCol && (
                        <td className="mono" style={{ textAlign: 'right' }}>
                          {row.hasMpStockData
                            ? <span style={{ color: row.mpStock === 0 ? 'var(--accent, #D85A30)' : 'inherit' }}>
                              {(row.mpStock || 0).toLocaleString('id-ID')}
                            </span>
                            : <span className="muted">—</span>}
                        </td>
                      )}
                      {hasStock && (
                        <td style={{ whiteSpace: 'nowrap' }}>
                          {row.unit
                            ? <span>{row.unit}</span>
                            : <span className="muted">—</span>}
                        </td>
                      )}
                      {hasStock && (
                        <td className="mono" style={{ textAlign: 'right' }}>
                          {row.hpp ? formatRupiah(row.hpp) : <span className="muted">—</span>}
                        </td>
                      )}
                      {hasStock && (
                        <td className="mono" style={{ textAlign: 'right' }}>
                          {row.totalHpp ? formatRupiah(row.totalHpp) : <span className="muted">—</span>}
                        </td>
                      )}
                      {hasStock && (
                        <td className="mono" style={{ textAlign: 'right' }}>
                          {row.ssr != null ? row.ssr.toFixed(2) : <span className="muted">—</span>}
                        </td>
                      )}
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem', marginTop: '0.5rem' }}>
            <Pagination
              page={safePage}
              totalPages={totalPages}
              pageSize={pageSize}
              onPageChange={setPage}
              onPageSizeChange={setPageSize}
              totalRows={rows.length}
            />
            {exportOptions && rows.length > 0 && (
              <ExportSplitBtnSm
                allRows={rows}
                pageRows={pageRows}
                exportOptions={exportOptions}
              />
            )}
          </div>
        </>
      )}
      {previewImage && (
        <ImagePreviewModal
          url={previewImage.url}
          alt={previewImage.alt}
          onClose={() => setPreviewImage(null)}
        />
      )}
    </>
  )
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function ProdukTerlarisPage() {
  const [loggedIn, setLoggedIn] = useState(false)
  const [checkingSession, setCheckingSession] = useState(true)
  const [password, setPassword] = useState('')
  const [loginError, setLoginError] = useState(null)
  const [loginLoading, setLoginLoading] = useState(false)

  // Periods
  const [periods, setPeriods] = useState([])
  const [selectedId, setSelectedId] = useState('')

  // Data
  const [payload, setPayload] = useState(null)
  const [dataLoading, setDataLoading] = useState(false)
  const [dataError, setDataError] = useState(null)

  // Date / account / category filters
  const [filters, setFilters] = useState({
    account: '',
    category: '',
    dateFrom: '',
    dateTo: '',
  })

  // Ref to track current page rows for "export displayed" option
  const pageRowsRef = useRef([])

  // Sort
  const [sortBy, setSortBy] = useState('kuantitas')
  const [groupMode, setGroupMode] = useState('variant') // 'variant' | 'induk'

  // Kolom "Tipe" cuma ada di mode "Per SKU Gabungan" — kalau filternya masih
  // aktif terus mode dipindah ke "Per Varian", baris di mode itu jadi gak
  // punya field `tipe` sama sekali dan filternya bakal cocok ke NOL baris
  // (tabel kelihatan kosong tanpa penjelasan). Makanya filter Tipe di-reset
  // tiap kali mode ganti.
  const handleGroupModeChange = useCallback((mode) => {
    setGroupMode(mode)
    setColFilters(prev => {
      if (!prev.tipe) return prev
      const next = { ...prev }
      delete next.tipe
      return next
    })
  }, [])
  const [sortDir, setSortDir] = useState('desc')

  // Kolom teks (Nama Barang, Kode Barang, Brand) default ascending (A→Z) saat
  // pertama diklik; kolom angka default descending (terbesar dulu) — klik lagi
  // di kolom yang sama membalik arahnya.
  const handleSortChange = useCallback((col) => {
    if (sortBy === col) {
      setSortDir(d => (d === 'asc' ? 'desc' : 'asc'))
    } else {
      setSortBy(col)
      setSortDir(TEXT_SORT_COLS.includes(col) ? 'asc' : 'desc')
    }
  }, [sortBy])

  // Search
  const [searchQuery, setSearchQuery] = useState('')

  // Column filters — { namaBarang: {op,value,value2}, kuantitas: {...}, hargaProduk: {...} }
  const [colFilters, setColFilters] = useState({})

  // Stock lookup: { kodeBarang: { brand, stock } } — digabung dari underwear + sport
  const [stockLookup, setStockLookup] = useState(null)
  const [stockError, setStockError] = useState(null)

  // Gambar per SKU — { kode: urlGambar } — disimpan di server (Vercel Blob) lewat
  // /api/sku-images & /api/upload-sku-images, jadi sekali upload langsung
  // kelihatan di semua browser/device, bukan cuma tersimpan lokal di sesi ini.
  const [imageLookup, setImageLookup] = useState(null)       // null = belum dimuat dari server
  const [imageMeta, setImageMeta] = useState({ count: 0, savedAt: null, exists: false })
  const [imageError, setImageError] = useState(null)         // gagal MEMUAT mapping dari server
  const [imageUploadError, setImageUploadError] = useState(null) // gagal UPLOAD file baru
  const [imageUploading, setImageUploading] = useState(false)
  const [showImages, setShowImages] = useState(false) // default: sembunyi

  // Index dengan key sudah dinormalisasi (uppercase, spasi dirapikan) — dibangun
  // sekali tiap kali mapping gambar berubah, dipakai baik buat enrichment
  // (mpStock, biar bisa difilter/diurutkan) maupun buat render kolom Gambar.
  const imageIndex = useMemo(() => buildSkuIndex(imageLookup), [imageLookup])

  // Catatan per baris (kodeBarang) — { [kodeBarang]: { text, updatedAt } },
  // disimpan di server (Vercel Blob) lewat /api/notes, jadi persist & kelihatan
  // di semua browser/device.
  const [notes, setNotes] = useState({})
  const [notesError, setNotesError] = useState(null)
  const [savingNoteFor, setSavingNoteFor] = useState(null) // kodeBarang yang lagi disimpan

  const loadNotes = useCallback(async () => {
    setNotesError(null)
    try {
      const res = await fetch('/api/notes', { cache: 'no-store' })
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `Gagal memuat catatan (${res.status})`)
      const data = await res.json()
      setNotes(data.notes || {})
    } catch (err) {
      setNotesError(err.message)
    }
  }, [])

  const saveNote = useCallback(async (kodeBarang, text) => {
    setSavingNoteFor(kodeBarang)
    const trimmed = text.trim()
    try {
      const res = await fetch('/api/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kodeBarang, text: trimmed }),
      })
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `Gagal menyimpan catatan (${res.status})`)
      const result = await res.json()
      setNotes(prev => {
        const next = { ...prev }
        if (result.deleted) {
          delete next[kodeBarang]
        } else {
          next[kodeBarang] = { text: result.text, updatedAt: result.updatedAt }
        }
        return next
      })
      return true
    } catch (err) {
      setNotesError(err.message)
      return false
    } finally {
      setSavingNoteFor(null)
    }
  }, [])

  const deleteNote = useCallback((kodeBarang) => saveNote(kodeBarang, ''), [saveNote])

  const loadSkuImages = useCallback(async () => {
    setImageError(null)
    try {
      const res = await fetch('/api/sku-images', { cache: 'no-store' })
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `Gagal memuat data gambar SKU (${res.status})`)
      const data = await res.json()
      setImageLookup(data.bySku || {})
      setImageMeta({ count: data.count ?? 0, savedAt: data.savedAt ?? null, exists: !!data.exists })
    } catch (err) {
      setImageError(err.message)
      setImageLookup({})
    }
  }, [])

  const handleImageFile = useCallback((file) => {
    setImageUploading(true)
    setImageUploadError(null)
    ;(async () => {
      try {
        // File-nya di-PARSE DI BROWSER dulu (bukan dikirim mentah ke server) —
        // hasil parsing (JSON) jauh lebih kecil daripada file .xlsx aslinya,
        // supaya tidak kena batas 4.5MB ukuran body request di Vercel Functions
        // (file dengan belasan-puluhan ribu baris SKU bisa >4MB dalam bentuk
        // .xlsx mentah dan gagal terkirim tanpa pesan error yang jelas).
        const arrayBuffer = await file.arrayBuffer()
        const { bySku, count } = parseSkuImageFile(arrayBuffer)

        const res = await fetch('/api/upload-sku-images', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ bySku, count }),
        })
        if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `Gagal mengupload file (${res.status})`)
        await loadSkuImages()
        setShowImages(true) // langsung nyalakan toggle setelah upload berhasil
      } catch (err) {
        setImageUploadError(err.message || 'Gagal mengupload file gambar SKU.')
      } finally {
        setImageUploading(false)
      }
    })()
  }, [loadSkuImages])

  const handleToggleShowImages = useCallback(() => {
    setShowImages(v => !v)
  }, [])

  const handleColFilterChange = useCallback((col, f) => {
    setColFilters(prev => ({ ...prev, [col]: f }))
  }, [])

  // Ambil underwear & sport TERPISAH (bukan satu request gabungan) — supaya
  // masing-masing response tetap kecil. Kalau digabung jadi satu response di
  // server, totalnya bisa kelewat batas 4.5MB Vercel Function begitu salah
  // satu katalog (mis. underwear) sudah puluhan ribu SKU — request itu gagal
  // dengan 413, dan sebelumnya kegagalan itu didiamkan begitu saja sehingga
  // stock (termasuk punya kategori lain yang sebetulnya baik-baik saja)
  // kelihatan "hilang" tanpa pesan apapun.
  const loadStock = useCallback(async () => {
    setStockError(null)
    const results = await Promise.allSettled([
      fetch('/api/stock-data?type=underwear', { cache: 'no-store' }).then(async res => {
        if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `Gagal memuat stock underwear (${res.status})`)
        return res.json()
      }),
      fetch('/api/stock-data?type=sport', { cache: 'no-store' }).then(async res => {
        if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `Gagal memuat stock sport (${res.status})`)
        return res.json()
      }),
    ])

    const [underwearResult, sportResult] = results
    const merged = {}
    // Kalau kode yang sama ada di dua file (di data kamu: SEMUA 616 kode sport
    // ternyata juga ada di file underwear — kemungkinan besar underwear.xls
    // adalah export inventaris LENGKAP, bukan katalog khusus underwear), kedua
    // versinya disimpan terpisah per kode (bukan yang satu menimpa yang lain).
    // Nanti getStockInfo() yang memutuskan: gabungkan stock-nya saat filter
    // kategori "Semua", atau pakai cuma salah satu saat pill Underwear/Sport dipilih.
    if (sportResult.status === 'fulfilled') {
      for (const [kode, entry] of Object.entries(sportResult.value.byKodePenuh || {})) {
        merged[kode] = { sport: entry, underwear: null }
      }
    }
    if (underwearResult.status === 'fulfilled') {
      for (const [kode, entry] of Object.entries(underwearResult.value.byKodePenuh || {})) {
        merged[kode] = merged[kode] ? { ...merged[kode], underwear: entry } : { underwear: entry, sport: null }
      }
    }

    const failures = []
    if (underwearResult.status === 'rejected') failures.push(`Underwear: ${underwearResult.reason.message}`)
    if (sportResult.status === 'rejected') failures.push(`Sport: ${sportResult.reason.message}`)

    if (failures.length) {
      setStockError(`Sebagian data stock gagal dimuat — ${failures.join(' · ')}. Kolom Brand/Stock/HPP/SSR untuk kategori itu mungkin tidak akurat.`)
    }
    setStockLookup(merged)
  }, [])

  // ── Session check ────────────────────────────────────────────────────────────
  useEffect(() => {
    fetch('/api/session', { cache: 'no-store' })
      .then(async (res) => {
        setCheckingSession(false)
        if (!res.ok) return
        setLoggedIn(true)
        loadStock()
        loadSkuImages()
        loadNotes()

        // Default halaman pertama kali dibuka: "30 hari terakhir" (gabungan semua
        // periode, difilter ke 30 hari terakhir) — bukan cuma periode terbaru.
        const list = await loadPeriods()
        if (list.length > 0) {
          setSelectedId(ALL_MERGED_ID)
          loadAllPeriodsMerged(list, last30DaysRange())
        } else {
          loadData('') // belum ada periode tersimpan sama sekali — fallback lama
        }
      })
      .catch(() => setCheckingSession(false))
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // ── Load periods ─────────────────────────────────────────────────────────────
  const loadPeriods = useCallback(async () => {
    const res = await fetch('/api/barang-terlaris-periods', { cache: 'no-store' })
    if (!res.ok) return []
    const list = await res.json()
    setPeriods(list)
    return list
  }, [])

  // ── Load data ─────────────────────────────────────────────────────────────────
  const loadData = useCallback(async (id) => {
    setDataLoading(true)
    setDataError(null)
    try {
      const d = await fetchBTData(id)
      setPayload(d)
    } catch (err) {
      setDataError(err.message)
      setPayload(null)
    } finally {
      setDataLoading(false)
    }
  }, [])

  // "Semua Periode (gabungan)" — gabungkan rawRows dari SEMUA periode (JSON bulan)
  // yang tersimpan jadi satu pool. Setelah ini, filter Tanggal mulai/akhir yang
  // sudah ada bisa dipakai bebas untuk rentang berapa pun (30 hari, 60 hari, dst)
  // tanpa dibatasi cuma 2 periode terbaru. Optional dateRangeOverride dipakai oleh
  // tombol preset "30 hari terakhir" supaya bisa switch pool + set tanggal sekaligus.
  const loadAllPeriodsMerged = useCallback(async (periodList, dateRangeOverride) => {
    setDataLoading(true)
    setDataError(null)
    try {
      const idsToFetch = periodList.map(p => p.id) // semua periode tersimpan
      if (idsToFetch.length === 0) {
        throw new Error('Belum ada periode data yang tersimpan.')
      }

      const results = await Promise.all(idsToFetch.map(id => fetchBTData(id)))

      const rawRows = results.flatMap(r => r?.analysis?.rawRows || [])
      const accounts = Array.from(new Set(results.flatMap(r => r?.analysis?.accounts || [])))

      if (!rawRows.length) {
        throw new Error('Tidak ada transaksi pada periode yang tersimpan.')
      }

      const sortedKeys = rawRows.map(r => r.dateKey).sort()
      const firstDateKey = sortedKeys[0]
      const lastDateKey = sortedKeys[sortedKeys.length - 1]

      setPayload({
        periodId: ALL_MERGED_ID,
        analysis: {
          rawRows,
          accounts,
          firstDateKey,
          lastDateKey,
          periodLabel: `Semua Periode (gabungan) — ${formatDateLabel(firstDateKey)} – ${formatDateLabel(lastDateKey)}`,
        },
      })

      if (dateRangeOverride) {
        setFilters(f => ({ ...f, dateFrom: dateRangeOverride.dateFrom, dateTo: dateRangeOverride.dateTo }))
      }
    } catch (err) {
      setDataError(err.message)
      setPayload(null)
    } finally {
      setDataLoading(false)
    }
  }, [])

  // Ganti periode = reset filter tanggal manual. Tanpa ini, tanggal dari periode
  // sebelumnya (mis. Juli) bisa nyangkut dan bikin periode baru (mis. Juni)
  // kelihatan kosong padahal datanya ada, cuma ketutup filter tanggal yang stale.
  const handlePeriodChange = useCallback((newId) => {
    setSelectedId(newId)
    setFilters(f => ({ ...f, dateFrom: '', dateTo: '' }))
    if (newId === ALL_MERGED_ID) {
      loadAllPeriodsMerged(periods)
    } else {
      loadData(newId)
    }
  }, [loadData, loadAllPeriodsMerged, periods])

  // Preset "30 hari terakhir" — tombol di sebelah filter tanggal manual (bukan
  // opsi dropdown), supaya tidak ada 2 kontrol yang rebutan makna atas
  // filters.dateFrom/dateTo. Ini cuma mengisi tanggal seperti kalau user
  // ketik manual, sekali pakai — bukan mode yang "menempel" terus di dropdown.
  const handleQuickLast30Days = useCallback(() => {
    const range = last30DaysRange()
    if (selectedId === ALL_MERGED_ID) {
      setFilters(f => ({ ...f, dateFrom: range.dateFrom, dateTo: range.dateTo }))
    } else {
      setSelectedId(ALL_MERGED_ID)
      loadAllPeriodsMerged(periods, range)
    }
  }, [selectedId, periods, loadAllPeriodsMerged])

  // ── Login ─────────────────────────────────────────────────────────────────────
  const handleLogin = useCallback(async (e) => {
    e.preventDefault()
    setLoginError(null)
    setLoginLoading(true)
    try {
      const res = await fetch('/api/viewer-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      })
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'Password salah.')
      setLoggedIn(true)
      await loadPeriods()
      await loadData('')
      loadStock()
      loadSkuImages()
      loadNotes()
    } catch (err) {
      setLoginError(err.message)
    } finally {
      setLoginLoading(false)
    }
  }, [password, loadPeriods, loadData, loadStock, loadSkuImages, loadNotes])

  // ── Derived data ──────────────────────────────────────────────────────────────
  const analysis = payload?.analysis
  const rawRows = analysis?.rawRows || []
  const accounts = analysis?.accounts || []
  const hasStock = stockLookup !== null

  useEffect(() => {
    if (!analysis) return
    setFilters(f => ({
      ...f,
      dateFrom: f.dateFrom || analysis.firstDateKey || '',
      dateTo: f.dateTo || analysis.lastDateKey || '',
    }))
  }, [analysis?.firstDateKey, analysis?.lastDateKey]) // eslint-disable-line react-hooks/exhaustive-deps

  const enrichedRows = useMemo(() => {
    const hasStockMaster = !!stockLookup && Object.keys(stockLookup).length > 0

    // 1. base rows — every stock SKU first (matched with sales by kode), or the
    //    old sales-grouped view if no stock master has been uploaded yet
    let rows = hasStockMaster
      ? buildStockFirstRows(rawRows, filters, stockLookup)
      : aggregateRows(rawRows, filters)

    // 2. merge in brand/stock so they can be filtered & sorted like any other column
    rows = enrichWithStock(rows, stockLookup, filters.category)

    // 3. merge in MP Stock (stock marketplace dari file gambar SKU) — sama
    //    alasannya, biar bisa difilter & diurutkan seperti kolom lain.
    rows = enrichWithMpStock(rows, imageIndex)

    return rows
  }, [rawRows, filters, stockLookup, imageIndex])

  // Semua brand yang ada untuk periode/filter tanggal saat ini — dipakai buat
  // checklist di kolom Brand. Diambil SEBELUM search/kolom-filter lain supaya
  // daftar pilihannya tidak ikut menyusut saat sedang milih brand.
  const brandOptions = useMemo(() => {
    return Array.from(new Set(
      enrichedRows.map(r => r.brand).filter(b => b && b !== '—')
    )).sort((a, b) => a.localeCompare(b, 'id'))
  }, [enrichedRows])

  const filteredRows = useMemo(() => {
    let rows = groupMode === 'induk' ? groupByParentSku(enrichedRows) : enrichedRows

    // 3. global search — flexible/fuzzy: split query into words and require
    //    every word to appear somewhere in the product name (in any order,
    //    ignoring separators like "-"). This way "BRA HOOK HITAM" or just
    //    "HOOK HITAM" will still match a name like "BRA HOOK-01-HITAM".
    if (searchQuery.trim()) {
      const keywords = searchQuery.trim().toLowerCase().split(/\s+/).filter(Boolean)
      rows = rows.filter(r => {
        const name = r.namaBarang.toLowerCase()
        return keywords.every(kw => name.includes(kw))
      })
    }

    // 4. column filters (namaBarang, brand, kuantitas, hargaProduk, stock)
    rows = applyColFilter(rows, colFilters)

    // 5. sort
    rows = sortRows(rows, sortBy, sortDir)

    // 6. re-rank after all filters
    return rows.map((r, i) => ({ ...r, rank: i + 1 }))
  }, [enrichedRows, groupMode, searchQuery, colFilters, sortBy, sortDir])

  // ── Active filter description ──────────────────────────────────────────────────
  const activeFilterDesc = useMemo(() => {
    const parts = []
    if (filters.account) parts.push(`Akun: ${filters.account}`)
    if (filters.category) parts.push(`Kategori: ${filters.category}`)
    if (filters.dateFrom || filters.dateTo) {
      const from = filters.dateFrom || analysis?.firstDateKey || '…'
      const to = filters.dateTo || analysis?.lastDateKey || '…'
      parts.push(`Tanggal: ${from} s.d. ${to}`)
    }
    // add active column filters
    const colLabels = {
      kodeBarang: 'Kode Barang', namaBarang: 'Nama Barang', kuantitas: 'Terjual', hargaProduk: 'Harga Produk',
      brand: 'Brand', stock: 'Stock', hpp: 'HPP PCS', totalHpp: 'Total HPP', ssr: 'SSR', tipe: 'Tipe',
    }
    for (const [col, f] of Object.entries(colFilters)) {
      if (!f.op) continue
      if (f.op === 'in') {
        if (!f.values || f.values.length === 0) continue
        parts.push(`${colLabels[col]}: ${f.values.join(', ')}`)
        continue
      }
      const noVal = ['is_empty', 'is_not_empty'].includes(f.op)
      if (!noVal && f.value === '' && f.op !== 'between') continue
      const opLabel = [...TEXT_OPS, ...NUM_OPS].find(o => o.value === f.op)?.label || f.op
      const valPart = noVal ? '' : f.op === 'between' ? ` ${f.value}–${f.value2}` : ` "${f.value}"`
      parts.push(`${colLabels[col]}: ${opLabel}${valPart}`)
    }
    return parts.length ? parts.join(' · ') : null
  }, [filters, analysis, colFilters])

  // Count active column filters for badge
  const activeColFilterCount = useMemo(() => {
    return Object.values(colFilters).filter(f => {
      if (!f.op) return false
      if (f.op === 'in') return !!(f.values && f.values.length > 0)
      if (['is_empty', 'is_not_empty'].includes(f.op)) return true
      return f.value !== ''
    }).length
  }, [colFilters])

  const resetColFilters = () => setColFilters({})

  // ── Render ────────────────────────────────────────────────────────────────────

  if (checkingSession) {
    return <div className="app-shell admin-login-shell"><p className="loading-text">Memeriksa sesi…</p></div>
  }

  if (!loggedIn) {
    return (
      <div className="app-shell admin-login-shell">
        <form className="login-card" onSubmit={handleLogin}>
          <p className="eyebrow">Produk Terlaris</p>
          <h1>Masukkan password tim untuk melihat</h1>
          <input
            type="password"
            placeholder="Password tim"
            value={password}
            onChange={e => setPassword(e.target.value)}
            className="login-input"
            autoFocus
          />
          {loginError && <p className="upload-error">{loginError}</p>}
          <button type="submit" className="btn-export" disabled={loginLoading}>
            {loginLoading ? 'Memeriksa…' : 'Masuk'}
          </button>
        </form>
      </div>
    )
  }

  return (
    <div className="app-shell app-shell--wide">
      <header className="app-header">
        <div>
          <p className="eyebrow">Dashboard penjualan</p>
          <h1>Produk Terlaris</h1>
        </div>
      </header>

      {/* ── Period picker ── */}
      {periods.length > 0 && (
        <div className="period-picker">
          <div className="period-picker-group">
            <label className="period-picker-label">Periode data</label>
            <select
              className="category-select"
              value={selectedId}
              onChange={e => handlePeriodChange(e.target.value)}
            >
              <option value="">Terbaru ({periods[0]?.label})</option>
              <option value={ALL_MERGED_ID}>Semua Periode (gabungan)</option>
              {periods.map(p => (
                <option key={p.id} value={p.id}>
                  {p.label} — {p.dateRange}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}

      {/* ── No data yet ── */}
      {!dataLoading && dataError && (
        <div className="upload-zone has-error">
          <p className="upload-title">Belum ada data untuk ditampilkan</p>
          <p className="upload-sub">{dataError}</p>
        </div>
      )}

      {stockError && (
        <div className="upload-zone has-error" style={{ marginBottom: '1rem' }}>
          <p className="upload-sub">⚠️ {stockError}</p>
        </div>
      )}

      {/* ── Main content ── */}
      {!dataError && (
        <div className="table-block">
          {/* Header row */}
          <div className="table-block-header">
            <h3 className="block-title">Produk paling banyak terjual</h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
              {analysis && (
                <span className="muted" style={{ fontSize: 13 }}>
                  {analysis.periodLabel}
                  {payload?.savedAt && (
                    <> &middot; Diperbarui {new Date(payload.savedAt).toLocaleString('id-ID')}</>
                  )}
                </span>
              )}
              {activeColFilterCount > 0 && (
                <button
                  className="pill-btn"
                  onClick={resetColFilters}
                  style={{
                    background: 'var(--accent-2, #6366f1)',
                    color: '#fff',
                    border: 'none',
                    fontSize: 12,
                  }}
                >
                  ✕ Reset filter kolom ({activeColFilterCount})
                </button>
              )}
              {filteredRows.length > 0 && (
                <ExportSplitBtnSm
                  allRows={filteredRows}
                  pageRows={pageRowsRef.current}
                  exportOptions={{
                    periodLabel: analysis?.periodLabel,
                    filterDesc: activeFilterDesc,
                    hasStock,
                  }}
                />
              )}
            </div>
          </div>

          {/* Filter bar */}
          {analysis && (
            <FilterBar
              accounts={accounts}
              filters={filters}
              onChange={newFilters => setFilters(newFilters)}
              onQuickLast30Days={handleQuickLast30Days}
            />
          )}

          {/* Active filter note */}
          {activeFilterDesc && (
            <p className="period-note" style={{ marginBottom: '0.75rem', marginTop: 0 }}>
              Filter aktif: {activeFilterDesc}
              {' '}({filteredRows.length} produk)
            </p>
          )}

          {/* Table */}
          <BestSellerTable
            rows={filteredRows}
            loading={dataLoading}
            sortBy={sortBy}
            sortDir={sortDir}
            onSortChange={handleSortChange}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            colFilters={colFilters}
            onColFilterChange={handleColFilterChange}
            stockLookup={stockLookup}
            brandOptions={brandOptions}
            groupMode={groupMode}
            onGroupModeChange={handleGroupModeChange}
            imageIndex={imageIndex}
            imageMeta={imageMeta}
            imageError={imageError}
            imageUploadError={imageUploadError}
            imageUploading={imageUploading}
            onImageFile={handleImageFile}
            showImages={showImages}
            onToggleShowImages={handleToggleShowImages}
            notes={notes}
            notesError={notesError}
            savingNoteFor={savingNoteFor}
            onSaveNote={saveNote}
            onDeleteNote={deleteNote}
            exportOptions={filteredRows.length > 0 ? {
              periodLabel: analysis?.periodLabel,
              filterDesc: activeFilterDesc,
              hasStock,
            } : null}
            onPageRowsChange={(pr) => { pageRowsRef.current = pr }}
          />
        </div>
      )}
    </div>
  )
}
