'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import SummaryCards from '@/components/SummaryCards'
import DailyTrendChart from '@/components/DailyTrendChart'
import BreakdownCharts from '@/components/BreakdownCharts'
import RankingTable from '@/components/RankingTable'
import PivotTable from '@/components/PivotTable'
import CategorySummary from '@/components/CategorySummary'
import CategoryDateDetail from '@/components/CategoryDateDetail'
import CompareView from '@/components/CompareView'
import AccountChart from '@/components/AccountChart'
import { exportToExcel, exportToExcelScreen, exportToExcelCompare } from '@/lib/exportExcel'
import { filterAnalysisByDateRange } from '@/lib/trimAnalysis'
import { exportElementToPdf } from '@/lib/exportPdf'

async function fetchData(id) {
  const url = id ? `/api/data?id=${encodeURIComponent(id)}` : '/api/data'
  const res = await fetch(url, { cache: 'no-store' })
  const body = await res.json()
  if (!res.ok) throw new Error(body.error || 'Gagal memuat data.')
  return body
}

function ExportDropdown({ analysis, categories, isComparing, payloadA, payloadB, labelA, labelB, alignMode, onExportPdf, pdfLoading, pdfProgress }) {
  const [open, setOpen] = useState(false)
  const wrapRef = useRef(null)

  useEffect(() => {
    if (!open) return
    function handleClick(e) {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [open])

  const pdfItem = onExportPdf && (
    <button
      className="export-dropdown-item"
      disabled={pdfLoading}
      onClick={() => { onExportPdf(); setOpen(false) }}
    >
      <span className="export-item-label">📄 {pdfLoading ? (pdfProgress || 'Membuat PDF…') : 'Unduh PDF'}</span>
      <span className="export-item-sub">Semua yang tampil di layar saat ini, termasuk grafik</span>
    </button>
  )

  if (isComparing) {
    // Compare mode: both options export the compare view, but "screen" is the exact aligned data
    const doExportCompare = () => {
      exportToExcelCompare(
        payloadA, payloadB, labelA, labelB, alignMode,
        payloadA?.categories || {}, payloadB?.categories || {}
      )
      setOpen(false)
    }
    return (
      <div className="export-split-wrap" ref={wrapRef}>
        <button className="btn-export-main" onClick={doExportCompare}>
          ↓ Unduh Excel
        </button>
        <button className="btn-export-caret" onClick={() => setOpen(v => !v)} title="Pilih format ekspor" aria-label="Pilih format ekspor">
          ▾
        </button>
        {open && (
          <div className="export-dropdown-menu">
            {pdfItem}
            <button className="export-dropdown-item" onClick={doExportCompare}>
              <span className="export-item-label">🖥️ Tampilan perbandingan</span>
              <span className="export-item-sub">Perbandingan {labelA} vs {labelB} — metrik, platform, pelanggan</span>
            </button>
            <button className="export-dropdown-item" onClick={() => {
              exportToExcel(payloadA?.analysis, payloadA?.categories || {}); setOpen(false)
            }}>
              <span className="export-item-label">📊 Laporan lengkap {labelA}</span>
              <span className="export-item-sub">Semua sheet detail untuk periode {labelA}</span>
            </button>
            <button className="export-dropdown-item" onClick={() => {
              exportToExcel(payloadB?.analysis, payloadB?.categories || {}); setOpen(false)
            }}>
              <span className="export-item-label">📊 Laporan lengkap {labelB}</span>
              <span className="export-item-sub">Semua sheet detail untuk periode {labelB}</span>
            </button>
          </div>
        )}
      </div>
    )
  }

  // Normal (single period) mode
  return (
    <div className="export-split-wrap" ref={wrapRef}>
      <button
        className="btn-export-main"
        onClick={() => { exportToExcel(analysis, categories); setOpen(false) }}
      >
        ↓ Unduh Excel
      </button>
      <button
        className="btn-export-caret"
        onClick={() => setOpen(v => !v)}
        title="Pilih format ekspor"
        aria-label="Pilih format ekspor"
      >
        ▾
      </button>
      {open && (
        <div className="export-dropdown-menu">
          {pdfItem}
          <button
            className="export-dropdown-item"
            onClick={() => { exportToExcel(analysis, categories); setOpen(false) }}
          >
            <span className="export-item-label">📊 Laporan lengkap (default)</span>
            <span className="export-item-sub">Ringkasan, pivot omset & order harian, kategori</span>
          </button>
          <button
            className="export-dropdown-item"
            onClick={() => { exportToExcelScreen(analysis, categories); setOpen(false) }}
          >
            <span className="export-item-label">🖥️ Semua yang tampil di layar</span>
            <span className="export-item-sub">Ringkasan, tren harian, platform & brand, pivot, kategori</span>
          </button>
        </div>
      )}
    </div>
  )
}

export default function HomePage() {
  const [loggedIn, setLoggedIn] = useState(false)
  const [checkingSession, setCheckingSession] = useState(true)
  const [password, setPassword] = useState('')
  const [loginError, setLoginError] = useState(null)
  const [loginLoading, setLoginLoading] = useState(false)

  const [periods, setPeriods] = useState([])
  const [selectedId, setSelectedId] = useState('') // '' = terbaru
  const [compareId, setCompareId] = useState('') // '' = tidak ada perbandingan
  const [alignMode, setAlignMode] = useState('aligned') // 'aligned' = selaraskan jumlah hari, 'full' = bandingkan periode penuh apa adanya

  const [payload, setPayload] = useState(null)
  const [comparePayload, setComparePayload] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  // ── Rentang tanggal yang ditampilkan (khusus mode satu periode) ──
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')

  // ── Ekspor PDF dari tampilan layar ──
  const exportRef = useRef(null)
  const [pdfLoading, setPdfLoading] = useState(false)
  const [pdfProgress, setPdfProgress] = useState('')

  const loadPeriods = useCallback(async () => {
    const res = await fetch('/api/periods', { cache: 'no-store' })
    if (res.ok) setPeriods(await res.json())
  }, [])

  const loadData = useCallback(async (id, compareIdVal) => {
    setLoading(true)
    setError(null)
    try {
      const main = await fetchData(id)
      setPayload(main)
      if (compareIdVal) {
        const compare = await fetchData(compareIdVal)
        setComparePayload(compare)
      } else {
        setComparePayload(null)
      }
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [])

  // Cek sesi di awal — kalau cookie valid, skip form login
  useEffect(() => {
    fetch('/api/data', { cache: 'no-store' })
      .then(async (res) => {
        if (res.status === 401) { setCheckingSession(false); return }
        const body = await res.json()
        if (res.ok || res.status === 404) {
          setLoggedIn(true)
          if (res.ok) setPayload(body)
        }
        setCheckingSession(false)
        loadPeriods()
      })
      .catch(() => setCheckingSession(false))
  }, [loadPeriods])

  const handleLogin = useCallback(async (e) => {
    e.preventDefault()
    setLoginError(null)
    setLoginLoading(true)
    try {
      const res = await fetch('/api/viewer-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      })
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'Password salah.')
      setLoggedIn(true)
      await loadPeriods()
      await loadData('', '')
    } catch (err) {
      setLoginError(err.message)
    } finally {
      setLoginLoading(false)
    }
  }, [password, loadData, loadPeriods])

  const handlePeriodChange = useCallback((newId) => {
    setSelectedId(newId)
    setCompareId('')
    setComparePayload(null)
    loadData(newId, '')
  }, [loadData])

  const handleCompareChange = useCallback((newCompareId) => {
    setCompareId(newCompareId)
    if (newCompareId) {
      loadData(selectedId, newCompareId)
    } else {
      setComparePayload(null)
    }
  }, [selectedId, loadData])

  const analysis = payload?.analysis
  const categories = payload?.categories || {}
  const isComparing = !!(comparePayload?.analysis)

  // Setiap kali periode (atau data) berganti, reset rentang tanggal ke rentang penuh periode itu.
  useEffect(() => {
    if (analysis) {
      setDateFrom(analysis.firstDateKey)
      setDateTo(analysis.lastDateKey)
    } else {
      setDateFrom('')
      setDateTo('')
    }
  }, [analysis?.firstDateKey, analysis?.lastDateKey, selectedId])

  const displayAnalysis = analysis ? filterAnalysisByDateRange(analysis, dateFrom, dateTo) : null
  const hasAnyCategory = Object.keys(categories).length > 0
  const hasDateRange = !!(analysis && analysis.dateKeys && analysis.dateKeys.length > 1)
  const isRangeFiltered = !!displayAnalysis?.dateFiltered
  const hasDisplayData = !!(displayAnalysis && displayAnalysis.dateKeys.length > 0)

  const handleDateFromChange = useCallback((value) => {
    setDateFrom(value)
    if (dateTo && value > dateTo) setDateTo(value)
  }, [dateTo])

  const handleDateToChange = useCallback((value) => {
    setDateTo(value)
    if (dateFrom && value < dateFrom) setDateFrom(value)
  }, [dateFrom])

  const resetDateRange = useCallback(() => {
    if (analysis) {
      setDateFrom(analysis.firstDateKey)
      setDateTo(analysis.lastDateKey)
    }
  }, [analysis])

  const handleExportPdf = useCallback(async () => {
    if (!exportRef.current || pdfLoading) return
    setPdfLoading(true)
    setPdfProgress('Menyiapkan…')
    try {
      const label = isComparing
        ? `${periods.find(p => p.id === (selectedId || periods[0]?.id))?.label || 'Periode A'} vs ${periods.find(p => p.id === compareId)?.label || 'Periode B'}`
        : (displayAnalysis?.periodLabel || analysis?.periodLabel || '')
      const fileSafeLabel = label.replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-+|-+$/g, '') || 'periode'
      await exportElementToPdf(
        exportRef.current,
        `dashboard-penjualan-${fileSafeLabel}`,
        {
          title: 'Analisa penjualan toko online',
          subtitle: isComparing ? `Perbandingan: ${label}` : `Periode: ${label}`,
          onProgress: setPdfProgress,
        }
      )
    } catch (err) {
      console.error(err)
      alert('Gagal membuat PDF: ' + (err.message || 'Terjadi kesalahan tak terduga.'))
    } finally {
      setPdfLoading(false)
      setPdfProgress('')
    }
  }, [isComparing, periods, selectedId, compareId, displayAnalysis, analysis, pdfLoading])

  if (checkingSession) {
    return <div className="app-shell admin-login-shell"><p className="loading-text">Memeriksa sesi…</p></div>
  }

  if (!loggedIn) {
    return (
      <div className="app-shell admin-login-shell">
        <form className="login-card" onSubmit={handleLogin}>
          <p className="eyebrow">Dashboard penjualan</p>
          <h1>Masukkan password tim untuk melihat</h1>
          <input type="password" placeholder="Password tim" value={password}
            onChange={(e) => setPassword(e.target.value)} className="login-input" autoFocus />
          {loginError && <p className="upload-error">{loginError}</p>}
          <button type="submit" className="btn-export" disabled={loginLoading}>
            {loginLoading ? 'Memeriksa…' : 'Masuk'}
          </button>
        </form>
      </div>
    )
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <div>
          <p className="eyebrow">Dashboard penjualan</p>
          <h1>Analisa penjualan toko online</h1>
        </div>
        {analysis && (
          <ExportDropdown
            analysis={displayAnalysis}
            categories={categories}
            isComparing={isComparing}
            payloadA={payload}
            payloadB={comparePayload}
            labelA={periods.find(p => p.id === (selectedId || periods[0]?.id))?.label || 'Periode A'}
            labelB={periods.find(p => p.id === compareId)?.label || 'Periode B'}
            alignMode={alignMode}
            onExportPdf={handleExportPdf}
            pdfLoading={pdfLoading}
            pdfProgress={pdfProgress}
          />
        )}
      </header>

      {/* ── Pemilih periode ── */}
      {periods.length > 0 && (
        <div className="period-picker">
          <div className="period-picker-group">
            <label className="period-picker-label">Periode</label>
            <select className="category-select" value={selectedId} onChange={(e) => handlePeriodChange(e.target.value)}>
              <option value="">Terbaru ({periods[0]?.label})</option>
              {periods.map((p) => (
                <option key={p.id} value={p.id}>{p.label} — {p.dateRange}</option>
              ))}
            </select>
          </div>
          <div className="period-picker-group">
            <label className="period-picker-label">Bandingkan dengan</label>
            <select className="category-select" value={compareId} onChange={(e) => handleCompareChange(e.target.value)}>
              <option value="">— Tidak dibandingkan —</option>
              {periods.filter((p) => p.id !== (selectedId || periods[0]?.id)).map((p) => (
                <option key={p.id} value={p.id}>{p.label} — {p.dateRange}</option>
              ))}
            </select>
          </div>
          {compareId && (
            <div className="period-picker-group">
              <label className="period-picker-label">Mode perbandingan</label>
              <div style={{ display: 'flex', gap: 6 }}>
                <button
                  type="button"
                  className="pill-btn"
                  onClick={() => setAlignMode('aligned')}
                  title="Bandingkan jumlah hari yang sama di kedua periode (mis. 1-10 Jul vs 1-10 Jun kalau Juli baru jalan 10 hari)"
                  style={alignMode === 'aligned' ? { background: 'var(--primary)', color: '#fff', borderColor: 'transparent' } : undefined}
                >
                  Selaraskan hari
                </button>
                <button
                  type="button"
                  className="pill-btn"
                  onClick={() => setAlignMode('full')}
                  title="Bandingkan kedua periode apa adanya, meski jumlah harinya beda (mis. Juli 31 hari vs Juni 30 hari)"
                  style={alignMode === 'full' ? { background: 'var(--primary)', color: '#fff', borderColor: 'transparent' } : undefined}
                >
                  Bandingkan penuh
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Pemilih rentang tanggal (khusus mode satu periode) ── */}
      {!loading && !isComparing && hasDateRange && (
        <div className="period-picker date-range-picker">
          <div className="period-picker-group">
            <label className="period-picker-label">Tampilkan dari tanggal</label>
            <input
              type="date"
              className="category-select"
              value={dateFrom}
              min={analysis.firstDateKey}
              max={analysis.lastDateKey}
              onChange={(e) => handleDateFromChange(e.target.value)}
            />
          </div>
          <div className="period-picker-group">
            <label className="period-picker-label">Sampai tanggal</label>
            <input
              type="date"
              className="category-select"
              value={dateTo}
              min={analysis.firstDateKey}
              max={analysis.lastDateKey}
              onChange={(e) => handleDateToChange(e.target.value)}
            />
          </div>
          {isRangeFiltered && (
            <button type="button" className="pill-btn" onClick={resetDateRange} title="Kembali ke seluruh rentang periode">
              ↺ Tampilkan semua ({analysis.dateKeys.length} hari)
            </button>
          )}
          {isRangeFiltered && (
            <span className="date-range-note">
              Menampilkan {displayAnalysis.dateKeys.length} hari — {displayAnalysis.dateKeys.length ? displayAnalysis.periodLabel : 'tidak ada transaksi di rentang ini'}
            </span>
          )}
        </div>
      )}

      {loading && <p className="loading-text">Memuat data…</p>}

      {!loading && error && (
        <div className="upload-zone has-error">
          <p className="upload-title">Belum ada data untuk ditampilkan</p>
          <p className="upload-sub">{error}</p>
        </div>
      )}

      <div ref={exportRef}>
        {/* ── Mode perbandingan ── */}
        {!loading && isComparing && (
          <CompareView
            payloadA={payload}
            payloadB={comparePayload}
            labelA={periods.find(p => p.id === (selectedId || periods[0]?.id))?.label || 'Periode A'}
            labelB={periods.find(p => p.id === compareId)?.label || 'Periode B'}
            alignMode={alignMode}
          />
        )}

        {/* ── Mode normal (satu periode) ── */}
        {!loading && !isComparing && displayAnalysis && hasDisplayData && (
          <main className="dashboard">
            <p className="period-note">
              Periode data: {displayAnalysis.periodLabel} ({displayAnalysis.dateKeys.length} hari aktif)
              {isRangeFiltered && <> &middot; disaring dari periode penuh {analysis.periodLabel}</>}
              {payload.savedAt && (
                <> &middot; Diperbarui {new Date(payload.savedAt).toLocaleString('id-ID')}</>
              )}
            </p>

            <SummaryCards data={displayAnalysis} />

            <section>
              <h2 className="section-title">Tren harian</h2>
              <DailyTrendChart daily={displayAnalysis.daily} />
            </section>

            <section>
              <AccountChart mode="single" data={displayAnalysis} />
            </section>

            <section>
              <h2 className="section-title">Komposisi omset</h2>
              <BreakdownCharts platformTotals={displayAnalysis.platformTotals} brandTotals={displayAnalysis.brandTotals} />
            </section>

            <section><RankingTable data={displayAnalysis} /></section>

            {hasAnyCategory && (
              <section><CategorySummary data={displayAnalysis} categories={categories} /></section>
            )}
            {hasAnyCategory && (
              <section><CategoryDateDetail data={displayAnalysis} categories={categories} /></section>
            )}

            <section><PivotTable data={displayAnalysis} /></section>
          </main>
        )}

        {!loading && !isComparing && displayAnalysis && !hasDisplayData && (
          <div className="upload-zone">
            <p className="upload-title">Tidak ada transaksi di rentang tanggal ini</p>
            <p className="upload-sub">Coba pilih rentang tanggal lain, atau tekan "Tampilkan semua" di atas.</p>
          </div>
        )}
      </div>

      <footer className="app-footer">
        <p>Data diperbarui oleh admin toko.</p>
        <Link href="/admin" className="admin-link">Masuk sebagai admin</Link>
      </footer>
    </div>
  )
}
